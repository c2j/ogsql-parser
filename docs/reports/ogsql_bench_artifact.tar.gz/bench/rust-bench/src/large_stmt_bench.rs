// Targeted benchmark for a small set of representative large/realistic SQL statements.
// Useful to compare parsers on a fixed set of statements rather than a mixed corpus.

use std::env;
use std::fs;
use std::time::Instant;

use ogsql_parser::Parser;
use ogsql_parser::token::tokenizer::Tokenizer;
use serde::Serialize;
use sqlparser::dialect::PostgreSqlDialect;
use sqlparser::parser::Parser as SqlParser;

const QUERIES: &[(&str, &str)] = &[
    (
        "simple_select",
        "SELECT id, name FROM users WHERE status = 'active'",
    ),
    (
        "join_3way",
        "SELECT u.id, u.name, COUNT(o.id) FROM users u JOIN orders o ON u.id = o.user_id JOIN products p ON o.product_id = p.id WHERE u.created_at > '2024-01-01' GROUP BY u.id, u.name HAVING COUNT(o.id) > 5",
    ),
    (
        "cte_chain",
        "WITH regional_sales AS (SELECT region, SUM(amount) AS total_sales FROM orders WHERE order_date >= '2024-01-01' GROUP BY region), top_regions AS (SELECT region FROM regional_sales WHERE total_sales > 1000000) SELECT r.region, r.total_sales, (SELECT COUNT(*) FROM customers c WHERE c.region = r.region) AS customer_count FROM regional_sales r WHERE r.region IN (SELECT region FROM top_regions) ORDER BY r.total_sales DESC LIMIT 10",
    ),
    (
        "window_fn",
        "SELECT id, name, department, salary, RANK() OVER (PARTITION BY department ORDER BY salary DESC) AS dept_rank, SUM(salary) OVER (PARTITION BY department) AS dept_total FROM employees",
    ),
    (
        "ddl_create_table",
        "CREATE TABLE orders (id BIGINT NOT NULL, user_id BIGINT NOT NULL, product_id BIGINT NOT NULL, amount DECIMAL(10,2) NOT NULL, status VARCHAR(20) NOT NULL DEFAULT 'pending', created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id), FOREIGN KEY (user_id) REFERENCES users(id), INDEX idx_status (status), INDEX idx_created (created_at))",
    ),
    (
        "bulk_insert_10",
        "INSERT INTO t (id, name, value) VALUES (1, 'a', 100), (2, 'b', 200), (3, 'c', 300), (4, 'd', 400), (5, 'e', 500), (6, 'f', 600), (7, 'g', 700), (8, 'h', 800), (9, 'i', 900), (10, 'j', 1000)",
    ),
    (
        "plpgsql_function",
        "CREATE OR REPLACE FUNCTION update_user_stats(p_user_id BIGINT) RETURNS VOID AS $$ BEGIN UPDATE users SET last_active = NOW() WHERE id = p_user_id; INSERT INTO user_stats (user_id, login_count, last_login) VALUES (p_user_id, 1, NOW()) ON CONFLICT (user_id) DO UPDATE SET login_count = user_stats.login_count + 1, last_login = NOW(); END; $$ LANGUAGE plpgsql",
    ),
];

#[derive(Serialize)]
struct Result {
    parser: &'static str,
    per_query: Vec<QueryResult>,
}

#[derive(Serialize)]
struct QueryResult {
    name: &'static str,
    sql: String,
    sql_len: usize,
    iters: usize,
    median_us: f64,
    p95_us: f64,
    throughput_qps: f64,
    ok: bool,
    err: Option<String>,
}

fn percentile(sorted: &[f64], p: f64) -> f64 {
    let idx = ((p / 100.0) * (sorted.len() as f64 - 1.0)).round() as usize;
    sorted[idx.min(sorted.len() - 1)]
}

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() < 3 {
        eprintln!("Usage: large-stmt-bench <which: ogsql|sqlparser> <output.json>");
        std::process::exit(1);
    }
    let which = &args[1];
    let output_path = &args[2];

    let iters: usize = 10_000;
    let mut per_query = Vec::new();

    if which == "ogsql" {
        eprintln!("[ogsql-large] running {} queries x {} iters", QUERIES.len(), iters);
        for (name, sql) in QUERIES {
            // warmup
            for _ in 0..100 {
                let _ = std::panic::catch_unwind(|| {
                    let toks = Tokenizer::new(sql).tokenize().ok()?;
                    Some(Parser::new(toks).parse())
                });
            }
            let mut lats = Vec::with_capacity(iters);
            let mut ok = true;
            let mut err_msg: Option<String> = None;
            for _ in 0..iters {
                let t0 = Instant::now();
                let r = std::panic::catch_unwind(|| {
                    match Tokenizer::new(sql).tokenize() {
                        Ok(toks) => Ok::<_, String>(Parser::new(toks).parse()),
                        Err(e) => Err(format!("Tok:{}", e)),
                    }
                });
                lats.push(t0.elapsed().as_nanos() as f64 / 1000.0);
                if let Err(e) = r {
                    ok = false;
                    err_msg = Some(format!("{:?}", e).chars().take(80).collect());
                }
            }
            lats.sort_by(|a, b| a.partial_cmp(b).unwrap());
            let med = lats[iters / 2];
            let p95 = percentile(&lats, 95.0);
            let total_sec: f64 = lats.iter().sum::<f64>() / 1_000_000.0;
            per_query.push(QueryResult {
                name,
                sql: sql.to_string(),
                sql_len: sql.len(),
                iters,
                median_us: med,
                p95_us: p95,
                throughput_qps: iters as f64 / total_sec,
                ok,
                err: err_msg,
            });
            eprintln!("  {}: median={:.2}us, p95={:.2}us, qps={:.0} {}", name, med, p95, iters as f64 / total_sec, if ok { "OK" } else { "ERR" });
        }
        let result = Result {
            parser: "ogsql-parser 0.8.3 (Rust, openGauss/GaussDB)",
            per_query,
        };
        fs::write(output_path, serde_json::to_string_pretty(&result).unwrap()).unwrap();
    } else if which == "sqlparser" {
        eprintln!("[sqlparser-large] running {} queries x {} iters", QUERIES.len(), iters);
        let dialect = PostgreSqlDialect {};
        for (name, sql) in QUERIES {
            for _ in 0..100 {
                let _ = std::panic::catch_unwind(|| SqlParser::parse_sql(&dialect, sql));
            }
            let mut lats = Vec::with_capacity(iters);
            let mut ok = true;
            let mut err_msg: Option<String> = None;
            for _ in 0..iters {
                let t0 = Instant::now();
                let r = std::panic::catch_unwind(|| SqlParser::parse_sql(&dialect, sql));
                lats.push(t0.elapsed().as_nanos() as f64 / 1000.0);
                if let Err(e) = r {
                    ok = false;
                    err_msg = Some(format!("{:?}", e).chars().take(80).collect());
                }
            }
            lats.sort_by(|a, b| a.partial_cmp(b).unwrap());
            let med = lats[iters / 2];
            let p95 = percentile(&lats, 95.0);
            let total_sec: f64 = lats.iter().sum::<f64>() / 1_000_000.0;
            per_query.push(QueryResult {
                name,
                sql: sql.to_string(),
                sql_len: sql.len(),
                iters,
                median_us: med,
                p95_us: p95,
                throughput_qps: iters as f64 / total_sec,
                ok,
                err: err_msg,
            });
            eprintln!("  {}: median={:.2}us, p95={:.2}us, qps={:.0} {}", name, med, p95, iters as f64 / total_sec, if ok { "OK" } else { "ERR" });
        }
        let result = Result {
            parser: "sqlparser-rs 0.52 (Rust, PostgreSQL dialect)",
            per_query,
        };
        fs::write(output_path, serde_json::to_string_pretty(&result).unwrap()).unwrap();
    } else {
        eprintln!("Unknown parser: {}", which);
        std::process::exit(1);
    }
    eprintln!("[done] wrote {}", output_path);
}
