// ogsql-parser AST dumper: parse SQL, emit JSON, then exit.
// Used for cross-parser semantic comparison.

use ogsql_parser::Parser;
use ogsql_parser::token::tokenizer::Tokenizer;
use std::env;
use std::fs;

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() < 2 {
        eprintln!("Usage: ogsql-ast-dump <sql_file>");
        std::process::exit(1);
    }
    let sql = fs::read_to_string(&args[1]).unwrap();
    let stmts = std::panic::catch_unwind(|| {
        let toks = match Tokenizer::new(sql.as_str()).tokenize() {
            Ok(t) => t,
            Err(_) => return None,
        };
        Some(Parser::new(toks).parse())
    });
    match stmts {
        Ok(Some(s)) => {
            println!("{}", serde_json::to_string(&s).unwrap());
        }
        _ => {
            eprintln!("Parse error");
            std::process::exit(1);
        }
    }
}
