// sqlparser-rs AST dumper - dumps the AST as JSON.
// Updated to match sqlparser-rs 0.52 API.

use sqlparser::ast::{SetExpr, Statement, TableFactor, Query, Expr};
use sqlparser::dialect::PostgreSqlDialect;
use sqlparser::parser::Parser as SqlParser;
use serde::Serialize;
use std::env;
use std::fs;

#[derive(Serialize)]
struct ColInfo { name: String }
#[derive(Serialize)]
struct TableInfo { name: String }
#[derive(Serialize)]
struct WhereInfo { raw: String }
#[derive(Serialize)]
struct Fact {
    stmt_type: String,
    tables: Vec<TableInfo>,
    columns: Vec<ColInfo>,
    where_: Vec<WhereInfo>,
    has_join: bool,
    has_subquery: bool,
    has_cte: bool,
    has_window: bool,
    has_union: bool,
}

fn table_factor_name(tf: &TableFactor) -> String {
    match tf {
        TableFactor::Table { name, .. } => name.to_string(),
        TableFactor::Derived { subquery, .. } => format!("({})", subquery.to_string().chars().take(20).collect::<String>()),
        _ => format!("{:?}", tf).chars().take(30).collect(),
    }
}

fn extract_from_query(q: &Query) -> Fact {
    let mut tables = Vec::new();
    let mut has_join = false;
    if let SetExpr::Select(select) = &*q.body {
        for twj in &select.from {
            tables.push(TableInfo { name: table_factor_name(&twj.relation) });
            if !twj.joins.is_empty() {
                has_join = true;
                for j in &twj.joins {
                    tables.push(TableInfo { name: table_factor_name(&j.relation) });
                }
            }
        }
        let columns: Vec<ColInfo> = select.projection.iter().map(|p| ColInfo {
            name: p.to_string(),
        }).collect();
        let where_str: Vec<WhereInfo> = if let Some(sel) = &select.selection {
            vec![WhereInfo { raw: sel.to_string() }]
        } else {
            vec![]
        };
        let has_subquery = where_str.iter().any(|w| w.raw.to_uppercase().contains("SELECT"));
        let has_cte = q.with.is_some();
        let cols_str: Vec<String> = columns.iter().map(|c| c.name.clone()).collect();
        let has_window = cols_str.iter().any(|c| c.to_uppercase().contains("OVER"));
        return Fact {
            stmt_type: "SELECT".to_string(),
            tables, columns, where_: where_str,
            has_join, has_subquery, has_cte, has_window,
            has_union: false,
        };
    }
    // Set operations
    Fact {
        stmt_type: "UNION".to_string(),
        tables: vec![], columns: vec![], where_: vec![],
        has_join: false, has_subquery: false, has_cte: false, has_window: false,
        has_union: true,
    }
}

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() < 2 {
        eprintln!("Usage: sqlparser-ast-dump <sql_file>");
        std::process::exit(1);
    }
    let sql = fs::read_to_string(&args[1]).unwrap();
    let dialect = PostgreSqlDialect {};
    let result = std::panic::catch_unwind(|| SqlParser::parse_sql(&dialect, &sql));
    let stmts: Vec<Statement> = match result {
        Ok(s) => match s {
            Ok(v) => v,
            Err(_) => { eprintln!("Parse error"); std::process::exit(1); }
        },
        Err(_) => { eprintln!("Parse panic"); std::process::exit(1); }
    };
    let mut facts = Vec::new();
    for stmt in stmts {
        let f = match stmt {
            Statement::Query(q) => extract_from_query(&q),
            Statement::Insert(i) => Fact {
                stmt_type: "INSERT".to_string(),
                tables: vec![TableInfo { name: i.table_name.to_string() }],
                columns: i.columns.iter().map(|c| ColInfo { name: c.to_string() }).collect(),
                where_: vec![], has_join: false, has_subquery: false, has_cte: false, has_window: false, has_union: false,
            },
            Statement::Update { table, selection, .. } => {
                let where_str = selection.as_ref().map(|w| vec![WhereInfo { raw: w.to_string() }]).unwrap_or_default();
                Fact {
                    stmt_type: "UPDATE".to_string(),
                    tables: vec![TableInfo { name: table.to_string() }],
                    columns: vec![], where_: where_str,
                    has_join: false, has_subquery: false, has_cte: false, has_window: false, has_union: false,
                }
            }
            Statement::Delete(d) => {
                let where_str = d.selection.as_ref().map(|w| vec![WhereInfo { raw: w.to_string() }]).unwrap_or_default();
                Fact {
                    stmt_type: "DELETE".to_string(),
                    tables: vec![TableInfo { name: d.from.to_string() }],
                    columns: vec![], where_: where_str,
                    has_join: false, has_subquery: false, has_cte: false, has_window: false, has_union: false,
                }
            }
            _ => Fact {
                stmt_type: "OTHER".to_string(),
                tables: vec![], columns: vec![], where_: vec![],
                has_join: false, has_subquery: false, has_cte: false, has_window: false, has_union: false,
            },
        };
        facts.push(f);
    }
    println!("{}", serde_json::to_string(&facts).unwrap());
}
