// ogsql-parser round-trip test: parse → format → compare with original.

use ogsql_parser::SqlFormatter;
use ogsql_parser::Parser;
use ogsql_parser::token::tokenizer::Tokenizer;
use serde::Serialize;
use std::env;
use std::fs;

#[derive(Serialize)]
struct Case {
    name: String,
    sql: String,
    parse_ok: bool,
    deparse_ok: bool,
    deparsed: Option<String>,
    error: Option<String>,
}

fn normalize(s: &str) -> String {
    // Collapse whitespace, strip trailing semicolons
    s.split_whitespace().collect::<Vec<_>>().join(" ").trim_end_matches(';').trim().to_string()
}

fn main() {
    let args: Vec<String> = env::args().collect();
    let input_path = &args[1];
    let output_path = &args[2];

    let raw = fs::read_to_string(input_path).unwrap();
    let mut cases: Vec<Case> = Vec::new();

    for line in raw.lines() {
        let line = line.trim();
        if line.is_empty() {
            continue;
        }
        // Support both TSV (name<TAB>sql) and the older comment-based format
        let (name, sql) = if let Some(tab_idx) = line.find('\t') {
            let n = line[..tab_idx].to_string();
            let s = line[tab_idx + 1..].to_string();
            (n, s)
        } else if let Some(rest) = line.strip_prefix("-- canonical_") {
            // Old format
            continue; // Need to find next non-comment line
        } else {
            continue;
        };

        let parse_result = std::panic::catch_unwind(|| {
            let toks = Tokenizer::new(sql.as_str()).tokenize();
            match toks {
                Ok(t) => Ok::<_, String>(Parser::new(t).parse()),
                Err(e) => Err(format!("Tok:{}", e)),
            }
        });
        let mut case = Case {
            name: name.clone(),
            sql: sql.clone(),
            parse_ok: false,
            deparse_ok: false,
            deparsed: None,
            error: None,
        };
        match parse_result {
            Ok(Ok(stmts)) => {
                case.parse_ok = true;
                if stmts.is_empty() {
                    case.error = Some("Empty parse".to_string());
                } else {
                    let formatter = SqlFormatter::new();
                    let mut outputs = Vec::new();
                    for stmt in &stmts {
                        outputs.push(formatter.format_statement(stmt));
                    }
                    case.deparse_ok = true;
                    case.deparsed = Some(outputs.join(";\n").trim().to_string());
                }
            }
            Ok(Err(e)) => {
                case.error = Some(e);
            }
            Err(e) => {
                case.error = Some(format!("Panic: {:?}", e).chars().take(80).collect());
            }
        }
        cases.push(case);
    }

    let result = serde_json::json!({
        "parser": "ogsql-parser 0.8.3 (Rust)",
        "cases": cases,
    });
    fs::write(output_path, serde_json::to_string_pretty(&result).unwrap()).unwrap();

    let parse_ok = cases.iter().filter(|c| c.parse_ok).count();
    let rt_ok = cases.iter().filter(|c| c.deparse_ok).count();
    let identical = cases.iter().filter(|c| {
        c.deparse_ok && c.deparsed.as_deref().map(normalize) == Some(normalize(&c.sql))
    }).count();
    println!("[ogsql-rt] parse: {}/{}, deparse: {}/{}, round-trip identical: {}/{}",
        parse_ok, cases.len(), rt_ok, cases.len(), identical, cases.len());
    for c in &cases {
        let status = if !c.parse_ok { "PARSE_ERR" }
                    else if !c.deparse_ok { "DEPARSE_ERR" }
                    else if normalize(c.deparsed.as_deref().unwrap_or("")) == normalize(&c.sql) { "OK" }
                    else { "DIFF" };
        let snippet = c.deparsed.as_deref()
            .or(c.error.as_deref())
            .unwrap_or("")
            .chars()
            .take(80)
            .collect::<String>();
        println!("  {:32} [{}]: {}", c.name, status, snippet);
    }
}
