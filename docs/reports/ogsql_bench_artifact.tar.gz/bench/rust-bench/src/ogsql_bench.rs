// ogsql-parser benchmark binary.
//
// Reads a TSV corpus (category<TAB>sql) and measures parsing performance:
//   * Per-statement latency (median, p95, p99)
//   * Throughput (queries/sec)
//   * Memory usage (RSS before/after)
//   * Success/error rate by category
//
// The corpus used in this benchmark is the GaussDB/openGauss SQL test suite
// shipped with ogsql-parser, normalized into individual statements.

use std::env;
use std::fs;
use std::path::Path;
use std::time::Instant;

use ogsql_parser::Parser;
use ogsql_parser::token::tokenizer::Tokenizer;
use serde::Serialize;

#[derive(Serialize)]
struct CategoryStats {
    n: usize,
    success: usize,
    success_rate: f64,
    median_latency_us: f64,
    mean_latency_us: f64,
}

#[derive(Serialize)]
struct BenchResult {
    parser: &'static str,
    corpus_size: usize,
    iterations: usize,
    total_queries: usize,
    elapsed_sec: f64,
    throughput_qps: f64,
    memory_kb_before: u64,
    memory_kb_after: u64,
    success_count: usize,
    error_count: usize,
    errors_by_type: std::collections::HashMap<String, usize>,
    overall_latency_us: LatencyStats,
    by_category: std::collections::HashMap<String, CategoryStats>,
}

#[derive(Serialize)]
struct LatencyStats {
    median: f64,
    mean: f64,
    p95: f64,
    p99: f64,
    min: f64,
    max: f64,
}

fn read_rss_kb() -> u64 {
    let s = fs::read_to_string("/proc/self/status").unwrap_or_default();
    for line in s.lines() {
        if let Some(rest) = line.strip_prefix("VmRSS:") {
            return rest.trim().split_whitespace().next().unwrap_or("0").parse().unwrap_or(0);
        }
    }
    0
}

fn percentile(sorted: &[f64], p: f64) -> f64 {
    let idx = ((p / 100.0) * (sorted.len() as f64 - 1.0)).round() as usize;
    sorted[idx.min(sorted.len() - 1)]
}

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() < 4 {
        eprintln!("Usage: ogsql-bench <corpus.tsv> <iterations> <output.json>");
        std::process::exit(1);
    }
    let corpus_path = &args[1];
    let iterations: usize = args[2].parse().expect("iterations must be integer");
    let output_path = &args[3];

    // Load corpus
    let raw = fs::read_to_string(corpus_path).expect("read corpus");
    let mut corpus: Vec<(String, String)> = Vec::new();
    for line in raw.lines() {
        if line.is_empty() {
            continue;
        }
        let (cat, sql) = line.split_once('\t').unwrap_or(("", ""));
        if !sql.is_empty() {
            corpus.push((cat.to_string(), sql.to_string()));
        }
    }
    eprintln!("[ogsql] loaded {} statements ({} iterations each)", corpus.len(), iterations);

    // Warmup
    eprintln!("[ogsql] warmup...");
    for (_, sql) in corpus.iter().take(50) {
        let _ = std::panic::catch_unwind(|| {
            let tokens = Tokenizer::new(sql).tokenize().ok()?;
            Parser::new(tokens).parse();
            Some(())
        });
    }

    let mem_before = read_rss_kb();
    let t0 = Instant::now();

    let mut all_latencies: Vec<f64> = Vec::with_capacity(corpus.len());
    let mut by_cat: std::collections::HashMap<String, Vec<(bool, f64)>> =
        std::collections::HashMap::new();
    let mut success_count = 0usize;
    let mut error_count = 0usize;
    let mut errors_by_type: std::collections::HashMap<String, usize> =
        std::collections::HashMap::new();

    for (cat, sql) in &corpus {
        let mut stmt_latencies: Vec<f64> = Vec::with_capacity(iterations);
        let mut ok = true;
        let mut err_kind = String::new();
        for _ in 0..iterations {
            let s = Instant::now();
            let result = std::panic::catch_unwind(|| {
                match Tokenizer::new(sql.as_str()).tokenize() {
                    Ok(toks) => Ok::<_, String>(Parser::new(toks).parse()),
                    Err(e) => Err(format!("TokenizerError:{}", e)),
                }
            });
            let elapsed = s.elapsed().as_nanos() as f64 / 1000.0; // to us
            stmt_latencies.push(elapsed);
            match result {
                Ok(_stmts) => {}
                Err(e) => {
                    if let Some(s) = e.downcast_ref::<String>() {
                        err_kind = s.split(':').next().unwrap_or("Error").to_string();
                    } else if let Some(s) = e.downcast_ref::<&str>() {
                        err_kind = s.split(':').next().unwrap_or("Error").to_string();
                    } else {
                        err_kind = "Panic".to_string();
                    }
                    ok = false;
                }
            }
        }
        // Use median across iterations
        stmt_latencies.sort_by(|a, b| a.partial_cmp(b).unwrap());
        let median = stmt_latencies[stmt_latencies.len() / 2];
        all_latencies.push(median);
        if ok {
            success_count += 1;
        } else {
            error_count += 1;
            *errors_by_type.entry(err_kind).or_insert(0) += 1;
        }
        by_cat.entry(cat.clone()).or_default().push((ok, median));
    }

    let elapsed = t0.elapsed().as_secs_f64();
    let mem_after = read_rss_kb();

    let mut sorted = all_latencies.clone();
    sorted.sort_by(|a, b| a.partial_cmp(b).unwrap());

    let overall_lat = LatencyStats {
        median: percentile(&sorted, 50.0),
        mean: sorted.iter().sum::<f64>() / sorted.len() as f64,
        p95: percentile(&sorted, 95.0),
        p99: percentile(&sorted, 99.0),
        min: *sorted.first().unwrap_or(&0.0),
        max: *sorted.last().unwrap_or(&0.0),
    };

    let mut cat_stats: std::collections::HashMap<String, CategoryStats> =
        std::collections::HashMap::new();
    for (cat, entries) in by_cat {
        let n = entries.len();
        let success = entries.iter().filter(|(ok, _)| *ok).count();
        let mut lats: Vec<f64> = entries.iter().map(|(_, l)| *l).collect();
        lats.sort_by(|a, b| a.partial_cmp(b).unwrap());
        cat_stats.insert(
            cat,
            CategoryStats {
                n,
                success,
                success_rate: success as f64 / n as f64,
                median_latency_us: percentile(&lats, 50.0),
                mean_latency_us: lats.iter().sum::<f64>() / lats.len() as f64,
            },
        );
    }

    let total_queries = corpus.len() * iterations;
    let result = BenchResult {
        parser: "ogsql-parser 0.8.3 (Rust, openGauss/GaussDB)",
        corpus_size: corpus.len(),
        iterations,
        total_queries,
        elapsed_sec: elapsed,
        throughput_qps: total_queries as f64 / elapsed,
        memory_kb_before: mem_before,
        memory_kb_after: mem_after,
        success_count,
        error_count,
        errors_by_type,
        overall_latency_us: overall_lat,
        by_category: cat_stats,
    };

    fs::write(output_path, serde_json::to_string_pretty(&result).unwrap())
        .expect("write output");
    eprintln!(
        "[ogsql] done: {:.0} q/s, success {}/{}, mem {} -> {} KB",
        result.throughput_qps,
        result.success_count,
        corpus.len(),
        result.memory_kb_before,
        result.memory_kb_after
    );
    eprintln!(
        "[ogsql] median latency: {:.2} µs, p99: {:.2} µs",
        result.overall_latency_us.median, result.overall_latency_us.p99
    );
}
