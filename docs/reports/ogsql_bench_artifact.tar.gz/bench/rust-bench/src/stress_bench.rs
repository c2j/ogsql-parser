// Stress test for the Rust parsers (ogsql, sqlparser) - matches the pglast stress test.

use std::collections::HashMap;
use std::env;
use std::fs;
use std::time::Instant;

use ogsql_parser::Parser;
use ogsql_parser::token::tokenizer::Tokenizer;
use serde::Serialize;
use sqlparser::dialect::PostgreSqlDialect;
use sqlparser::parser::Parser as SqlParser;

#[derive(Serialize)]
struct Case {
    sql_len: usize,
    iters: usize,
    ok: bool,
    err: Option<String>,
    median_us: f64,
    p95_us: f64,
    max_us: f64,
    throughput_qps: f64,
}

fn build_cases() -> HashMap<String, String> {
    let mut cases = HashMap::new();

    // 1k INSERT
    let rows_1k: Vec<String> = (0..1000).map(|i| format!("({}, 'name_{}_{}', {})", i, i, "x".repeat(20), i as f64 * 1.5)).collect();
    cases.insert("long_insert_1k".to_string(), format!("INSERT INTO t (id, name, val) VALUES {};", rows_1k.join(", ")));

    // 10k INSERT
    let rows_10k: Vec<String> = (0..10_000).map(|i| format!("({}, 'n{}')", i, i)).collect();
    cases.insert("long_insert_10k".to_string(), format!("INSERT INTO t (id, name) VALUES {};", rows_10k.join(", ")));

    // Deeply nested CTE
    let mut cte = "SELECT 1 AS x".to_string();
    for i in 0..20 {
        cte = format!("WITH c{} AS ({}) SELECT * FROM c{}", i, cte, i);
    }
    cases.insert("deeply_nested_cte_20".to_string(), cte);

    // Wide SELECT
    let cols: Vec<String> = (0..200).map(|i| format!("col_{} AS c{}", i, i)).collect();
    cases.insert("wide_select_200cols".to_string(), format!("SELECT {} FROM t", cols.join(", ")));

    // Many joined tables
    let mut joins = "t1".to_string();
    for i in 2..=30 {
        joins.push_str(&format!(" JOIN t{} ON t{}.id = t{}.id", i, i - 1, i));
    }
    cases.insert("many_joined_tables_30".to_string(), format!("SELECT t1.id FROM {}", joins));

    // Long identifier
    cases.insert("long_identifier_1k".to_string(), format!("SELECT {} FROM t", "a".repeat(1000)));

    // Edge cases
    cases.insert("empty_input".to_string(), "".to_string());
    cases.insert("whitespace_only".to_string(), "   \n\t  \n".to_string());
    cases.insert("single_semicolon".to_string(), ";".to_string());
    cases.insert("single_token".to_string(), "SELECT".to_string());
    cases.insert("unterminated_string".to_string(), "SELECT 'abc".to_string());
    cases.insert("unterminated_comment".to_string(), "SELECT /* abc".to_string());
    cases.insert("valid_trivial".to_string(), "SELECT 1".to_string());
    cases.insert("valid_minimal".to_string(), "SELECT a FROM b".to_string());

    // 50-level subquery
    let mut inner = "SELECT 1".to_string();
    for i in 0..50 {
        inner = format!("SELECT * FROM ({}) sub_{}", inner, i);
    }
    cases.insert("deeper_nesting".to_string(), inner);

    cases
}

fn percentile(sorted: &[f64], p: f64) -> f64 {
    let idx = ((p / 100.0) * (sorted.len() as f64 - 1.0)).round() as usize;
    sorted[idx.min(sorted.len() - 1)]
}

fn bench_ogsql(sql: &str, iters: usize) -> Case {
    let mut lats = Vec::with_capacity(iters);
    let mut ok = true;
    let mut err: Option<String> = None;
    for _ in 0..iters {
        let t0 = Instant::now();
        let r = std::panic::catch_unwind(|| {
            match Tokenizer::new(sql).tokenize() {
                Ok(toks) => Ok::<_, String>(Parser::new(toks).parse()),
                Err(e) => Err(format!("Tok:{}", e)),
            }
        });
        lats.push(t0.elapsed().as_nanos() as f64 / 1000.0);
        if let Err(e) = r {
            ok = false;
            err = Some(format!("{:?}", e).chars().take(80).collect());
        }
    }
    lats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let med = lats[iters / 2];
    let p95 = percentile(&lats, 95.0);
    let mx = *lats.last().unwrap();
    let total_sec: f64 = lats.iter().sum::<f64>() / 1_000_000.0;
    Case {
        sql_len: sql.len(),
        iters,
        ok,
        err,
        median_us: med,
        p95_us: p95,
        max_us: mx,
        throughput_qps: iters as f64 / total_sec,
    }
}

fn bench_sqlparser(sql: &str, iters: usize) -> Case {
    let dialect = PostgreSqlDialect {};
    let mut lats = Vec::with_capacity(iters);
    let mut ok = true;
    let mut err: Option<String> = None;
    for _ in 0..iters {
        let t0 = Instant::now();
        let r = std::panic::catch_unwind(|| SqlParser::parse_sql(&dialect, sql));
        lats.push(t0.elapsed().as_nanos() as f64 / 1000.0);
        if let Err(e) = r {
            ok = false;
            err = Some(format!("{:?}", e).chars().take(80).collect());
        }
    }
    lats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let med = lats[iters / 2];
    let p95 = percentile(&lats, 95.0);
    let mx = *lats.last().unwrap();
    let total_sec: f64 = lats.iter().sum::<f64>() / 1_000_000.0;
    Case {
        sql_len: sql.len(),
        iters,
        ok,
        err,
        median_us: med,
        p95_us: p95,
        max_us: mx,
        throughput_qps: iters as f64 / total_sec,
    }
}

#[derive(Serialize)]
struct Result {
    parser: String,
    results: HashMap<String, Case>,
}

fn main() {
    let args: Vec<String> = env::args().collect();
    let which = &args[1];
    let output_path = &args[2];
    let cases = build_cases();

    let parser_name = if which == "ogsql" {
        "ogsql-parser 0.8.3 (Rust, openGauss/GaussDB)"
    } else {
        "sqlparser-rs 0.52 (Rust, PostgreSQL dialect)"
    };

    let mut results = HashMap::new();
    for (name, sql) in &cases {
        let sql_len = sql.len();
        let iters: usize = if sql_len > 50_000 {
            10
        } else if sql_len > 10_000 {
            50
        } else if sql_len > 1000 {
            200
        } else {
            1000
        };

        let case = if which == "ogsql" {
            bench_ogsql(sql, iters)
        } else {
            bench_sqlparser(sql, iters)
        };

        let status = if case.ok { "OK".to_string() } else { format!("ERR:{}", case.err.as_deref().unwrap_or("?")) };
        println!("  {:32} (len={:6}, iters={:4}): median={:8.1}us, p95={:8.1}us, max={:8.1}us {}",
            name, sql_len, iters, case.median_us, case.p95_us, case.max_us, status);
        results.insert(name.clone(), case);
    }

    let result = Result {
        parser: parser_name.to_string(),
        results,
    };
    fs::write(output_path, serde_json::to_string_pretty(&result).unwrap()).unwrap();
    println!("\nSaved {}", output_path);
}
