// Cold-start latency benchmark: measures the time to first parse after process spawn.
// Important for CLI tools and short-lived processes.

use std::env;
use std::process::Command;
use std::time::Instant;

const QUERY: &str = "SELECT id, name FROM users WHERE status = 'active' AND age > 18 ORDER BY created_at DESC LIMIT 100";

fn main() {
    let args: Vec<String> = env::args().collect();
    let which = &args[1];
    let n: usize = args.get(2).and_then(|s| s.parse().ok()).unwrap_or(20);

    let binary = match which.as_str() {
        "ogsql" => "/workspace/bench/rust-bench/target/release/ogsql-bench",
        "sqlparser" => "/workspace/bench/rust-bench/target/release/sqlparser-bench",
        _ => panic!("Unknown parser: {}", which),
    };

    println!("[cold-start] {} runs of {} using {}", n, which, binary);
    let mut lats_ms = Vec::with_capacity(n);
    for i in 0..n {
        // Use a tiny corpus: just one statement
        let corpus_path = std::env::temp_dir().join(format!("bench_cold_{}.tsv", std::process::id()));
        std::fs::write(&corpus_path, format!("DQL\t{}", QUERY)).unwrap();
        let output_path = std::env::temp_dir().join(format!("bench_cold_{}.json", std::process::id()));

        let t0 = Instant::now();
        let status = Command::new(binary)
            .arg(&corpus_path)
            .arg("1")
            .arg(&output_path)
            .stdout(std::process::Stdio::null())
            .stderr(std::process::Stdio::null())
            .status()
            .expect("spawn");
        let elapsed = t0.elapsed();
        if !status.success() {
            eprintln!("  run {}: FAILED with status {:?}", i, status);
            continue;
        }
        lats_ms.push(elapsed.as_secs_f64() * 1000.0);
    }

    lats_ms.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let med = lats_ms[lats_ms.len() / 2];
    let mean = lats_ms.iter().sum::<f64>() / lats_ms.len() as f64;
    let p95_idx = ((0.95 * (lats_ms.len() as f64 - 1.0)).round() as usize).min(lats_ms.len() - 1);
    let p95 = lats_ms[p95_idx];
    let mn = *lats_ms.first().unwrap();
    let mx = *lats_ms.last().unwrap();
    println!("  N={}, min={:.1}ms, median={:.1}ms, p95={:.1}ms, max={:.1}ms, mean={:.1}ms",
        lats_ms.len(), mn, med, p95, mx, mean);
}
