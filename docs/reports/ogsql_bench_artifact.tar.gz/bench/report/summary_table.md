# Main Benchmark Summary

| 指标 | ogsql-parser 0.8.3 | sqlparser-rs 0.52 (PG dialect) | pglast 7.14 (libpg_query) |
|---|---|---|---|
| **吞吐量 (q/s, 9.6k 语料, 5 iters)** | 356,866 | 145,953 | 28,165 |
| **中位延迟 (µs)** | 1.97 | 4.93 | 29.89 |
| **p95 延迟 (µs)** | 5.92 | 15.27 | 82.40 |
| **p99 延迟 (µs)** | 11.30 | 32.47 | 148.00 |
| **解析成功率** | 100.0% | 100.0% | 79.2% |
| **进程内存 (RSS)** | 6.2 MB | 5.8 MB | 28.0 MB |
| **冷启动 (空 query)** | 2.5 ms | 2.5 ms | ~51 ms |
| **实现语言** | Rust (原生) | Rust (原生) | C (libpg_query) + Python ctypes |
| **解析算法** | 手写递归下降 | 手写递归下降 | Bison LALR(1) (PostgreSQL) |
| **目标方言** | openGauss/GaussDB | 通用 + 多方言插件 | PostgreSQL |
| **源代码行数** | 97,118 (含 AST/linter/formatter) | 36,590 (纯解析+AST) | ~20MB C 编译产物 |
