# Per-Statement Comparison

| 查询 | ogsql-parser 中位 (µs) | sqlparser-rs 中位 (µs) | pglast 中位 (µs) | ogsql 是 sqlparser 的 | ogsql 是 pglast 的 |
|---|---|---|---|---|---|
| `simple_select` (50 B) | 2.87 | 7.34 | 44.54 | 2.56x | 15.55x |
| `join_3way` (197 B) | 12.42 | 32.68 | 155.31 | 2.63x | 12.50x |
| `cte_chain` (428 B) | 18.75 | 49.73 | 255.14 | 2.65x | 13.60x |
| `window_fn` (181 B) | 8.27 | 19.28 | 105.45 | 2.33x | 12.76x |
| `ddl_create_table` (349 B) | 9.75 | 27.09 | 345.81 | 2.78x | 35.47x |
| `bulk_insert_10` (189 B) | 8.67 | 39.45 | 134.72 | 4.55x | 15.55x |
| `plpgsql_function` (356 B) | 15.38 | 7.26 | 44.53 | 0.47x | 2.90x |
