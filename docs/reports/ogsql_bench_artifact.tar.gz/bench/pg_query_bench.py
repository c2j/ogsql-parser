"""Benchmark for pglast (Python wrapper for libpg_query, the PostgreSQL parser)."""
import argparse
import json
import os
import resource
import statistics
import sys
import time
from pathlib import Path

import pglast
import psutil

PROCESS = psutil.Process(os.getpid())


def load_corpus(path: str):
    """Load tab-separated corpus of category<TAB>sql."""
    items = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.rstrip("\n")
            if not line:
                continue
            cat, _, sql = line.partition("\t")
            items.append((cat, sql))
    return items


def measure_memory_mb():
    """Get current RSS in MB."""
    return PROCESS.memory_info().rss / (1024 * 1024)


def bench_pglast(corpus, iterations: int, warmup: int = 100):
    """Run pglast benchmark on a corpus.

    Returns dict with per-statement-category stats, success rate, throughput, etc.
    """
    results_by_cat = {}
    overall_latencies_us = []
    success_count = 0
    error_count = 0
    errors_by_type = {}

    # Warmup
    print(f"[pglast] warmup ({warmup} iters)...", flush=True)
    for cat, sql in corpus[:warmup]:
        try:
            pglast.parse_sql(sql)
        except Exception:
            pass

    mem_before = measure_memory_mb()
    t_total_start = time.perf_counter()

    for cat, sql in corpus:
        latencies = []
        ok = True
        err_msg = None
        for _ in range(iterations):
            t0 = time.perf_counter_ns()
            try:
                pglast.parse_sql(sql)
            except Exception as e:
                ok = False
                err_msg = f"{type(e).__name__}: {str(e)[:60]}"
            t1 = time.perf_counter_ns()
            latencies.append(t1 - t0)
        if ok:
            success_count += 1
        else:
            error_count += 1
            err_type = err_msg.split(":")[0] if err_msg else "Unknown"
            errors_by_type[err_type] = errors_by_type.get(err_type, 0) + 1

        overall_latencies_us.append(statistics.median(latencies) / 1000)
        if cat not in results_by_cat:
            results_by_cat[cat] = {"n": 0, "latencies_us": [], "success": 0}
        results_by_cat[cat]["n"] += 1
        results_by_cat[cat]["success"] += int(ok)
        results_by_cat[cat]["latencies_us"].append(statistics.median(latencies) / 1000)

    t_total_end = time.perf_counter()
    mem_after = measure_memory_mb()

    total_queries = len(corpus) * iterations
    elapsed_sec = t_total_end - t_total_start
    throughput = total_queries / elapsed_sec

    return {
        "parser": "pglast (libpg_query, PostgreSQL grammar)",
        "total_statements": len(corpus),
        "iterations_per_statement": iterations,
        "total_queries": total_queries,
        "elapsed_sec": elapsed_sec,
        "throughput_qps": throughput,
        "memory_mb_before": mem_before,
        "memory_mb_after": mem_after,
        "memory_mb_delta": mem_after - mem_before,
        "success_count": success_count,
        "error_count": error_count,
        "errors_by_type": errors_by_type,
        "overall_latency_us": {
            "median": statistics.median(overall_latencies_us),
            "mean": statistics.mean(overall_latencies_us),
            "p95": sorted(overall_latencies_us)[int(len(overall_latencies_us) * 0.95)],
            "p99": sorted(overall_latencies_us)[int(len(overall_latencies_us) * 0.99)],
            "min": min(overall_latencies_us),
            "max": max(overall_latencies_us),
        },
        "by_category": {
            cat: {
                "n": v["n"],
                "success": v["success"],
                "median_latency_us": statistics.median(v["latencies_us"]),
                "mean_latency_us": statistics.mean(v["latencies_us"]),
                "success_rate": v["success"] / v["n"],
            }
            for cat, v in sorted(results_by_cat.items())
        },
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--corpus", required=True)
    parser.add_argument("--iterations", type=int, default=10)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    print(f"[pglast] loading corpus from {args.corpus}", flush=True)
    corpus = load_corpus(args.corpus)
    print(f"[pglast] loaded {len(corpus)} statements", flush=True)

    result = bench_pglast(corpus, args.iterations)
    result["system"] = {
        "cpu_count": psutil.cpu_count(),
        "total_memory_mb": psutil.virtual_memory().total / (1024 * 1024),
    }

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, "w") as f:
        json.dump(result, f, indent=2)

    print(f"[pglast] done: {result['throughput_qps']:.0f} q/s, "
          f"success {result['success_count']}/{result['total_statements']}, "
          f"mem {result['memory_mb_after']:.1f} MB", flush=True)
    print(f"[pglast] median latency: {result['overall_latency_us']['median']:.2f} µs", flush=True)


if __name__ == "__main__":
    main()
