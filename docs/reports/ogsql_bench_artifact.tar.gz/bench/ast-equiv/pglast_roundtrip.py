"""pglast round-trip test: parse → deparse → compare with original.

pglast uses libpg_query's deparser (pg_query_deparse) which round-trips
PostgreSQL syntax perfectly. We test on the same canonical SQL corpus.
"""
import json
import re
import sys

import pglast
import pglast.parser as pgparser


def normalize(s: str) -> str:
    return " ".join(s.split()).strip().rstrip(";").strip()


def deparse(node):
    """Try libpg_query's deparse on an AST node. Returns string or raises."""
    return pglast.deparse(node)


def main():
    input_path = sys.argv[1]
    output_path = sys.argv[2]

    cases = []
    with open(input_path) as f:
        for line in f:
            line = line.rstrip("\n")
            if not line.strip():
                continue
            tab = line.find("\t")
            if tab < 0:
                continue
            name = line[:tab]
            sql = line[tab + 1:]

            case = {
                "name": name,
                "sql": sql,
                "parse_ok": False,
                "deparse_ok": False,
                "deparsed": None,
                "error": None,
            }
            try:
                tree = pglast.parse_sql(sql)
                case["parse_ok"] = True
                # deparse each statement
                outputs = []
                for stmt in tree:
                    try:
                        outputs.append(deparse(stmt))
                    except Exception as e:
                        case["error"] = f"deparse_stmt: {type(e).__name__}: {str(e)[:80]}"
                if outputs:
                    case["deparse_ok"] = True
                    case["deparsed"] = "\n".join(outputs).strip()
            except Exception as e:
                case["error"] = f"{type(e).__name__}: {str(e)[:80]}"
            cases.append(case)

    result = {"parser": "pglast 7.14 (libpg_query C deparser)", "cases": cases}
    with open(output_path, "w") as f:
        json.dump(result, f, indent=2)

    parse_ok = sum(1 for c in cases if c["parse_ok"])
    rt_ok = sum(1 for c in cases if c["deparse_ok"])
    identical = sum(
        1 for c in cases
        if c["deparse_ok"] and normalize(c["deparsed"]) == normalize(c["sql"])
    )
    print(f"[pglast-rt] parse: {parse_ok}/{len(cases)}, deparse: {rt_ok}/{len(cases)}, "
          f"round-trip identical: {identical}/{len(cases)}")
    for c in cases:
        if not c["parse_ok"]:
            status = "PARSE_ERR"
        elif not c["deparse_ok"]:
            status = "DEPARSE_ERR"
        elif normalize(c["deparsed"]) == normalize(c["sql"]):
            status = "OK"
        else:
            status = "DIFF"
        snippet = (c.get("deparsed") or c.get("error") or "")[:80]
        print(f"  {c['name']:32s} [{status}]: {snippet}")


if __name__ == "__main__":
    main()
