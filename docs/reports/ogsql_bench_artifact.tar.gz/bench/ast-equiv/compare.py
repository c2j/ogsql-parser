"""Cross-parser semantic equivalence comparison.

Loads the four semantic-extraction JSONs (ogsql, sqlparser, pglast, jsqlparser)
and compares what each parser "sees" for each canonical SQL.

For each canonical statement, we extract a small set of "facts":
  - stmt_type
  - tables
  - columns (projected)
  - where conditions (loosely: as a string)
  - limit (if any)
  - has_join / has_subquery / has_cte / has_window (boolean flags)

Then we report for each fact: which parsers agree, which disagree.
"""
import json
import sys
from pathlib import Path

PARSERS = ["ogsql", "sqlparser", "pglast", "jsqlparser"]


def load_facts(path):
    path = Path(path)
    data = json.load(open(path))
    out = {}
    for c in data["cases"]:
        out[c['name']] = c
    return out


def normalize_columns(cols):
    """Sort + lowercase for comparison."""
    if not cols:
        return ()
    out = set()
    for c in cols:
        if c is None:
            continue
        s = str(c).lower().strip()
        # Strip aliases like " AS xxx" for column comparison
        if " as " in s:
            s = s.split(" as ")[0].strip()
        # Strip function calls to just function name
        if "(" in s:
            inner = s.split("(", 1)[0].strip()
            s = inner
        out.add(s)
    return tuple(sorted(out))


def normalize_tables(tables):
    if not tables:
        return ()
    out = set()
    for t in tables:
        if t is None:
            continue
        s = str(t).lower().strip()
        # Strip alias
        if " as " in s:
            s = s.split(" as ")[0].strip()
        if s.startswith("join:"):
            continue
        out.add(s)
    return tuple(sorted(out))


def extract_key_facts(case):
    """Pull the comparison facts out of a case record."""
    out = {
        "parse_ok": case.get("parse_ok", False),
        "stmt_type": None,
        "tables": (),
        "columns": (),
        "has_join": False,
        "has_subquery": False,
        "has_cte": False,
        "has_window": False,
        "has_union": False,
    }
    if not case.get("facts"):
        return out
    facts = case["facts"]
    if not facts:
        return out
    f = facts[0]  # first statement
    out["stmt_type"] = f.get("stmt_type")
    out["tables"] = normalize_tables(f.get("tables") or ([f["table"]] if f.get("table") else []))
    out["columns"] = normalize_columns(f.get("columns") or [])
    # Joins: check if "joins" key has anything, or there are multiple tables
    joins = f.get("joins") or []
    if joins and len(joins) > 0:
        out["has_join"] = True
    elif len(out["tables"]) >= 2 and out["stmt_type"] == "SELECT":
        out["has_join"] = True
    # Subquery: check WHERE
    where = f.get("where") or []
    for w in where:
        if isinstance(w, dict):
            if w.get("right") == "SUBQUERY" or "SUBQUERY" in str(w):
                out["has_subquery"] = True
            raw = str(w)
            if "IN (SELECT" in raw.upper() or "IN ( SELECT" in raw.upper():
                out["has_subquery"] = True
    # CTE
    ctes = f.get("ctes") or []
    if ctes and len(ctes) > 0:
        out["has_cte"] = True
    # Window: check columns for OVER keyword
    cols_str = " ".join(str(c) for c in f.get("columns") or [])
    if "over" in cols_str.lower() and "partition" in cols_str.lower():
        out["has_window"] = True
    # Union: stmt_type
    if f.get("stmt_type") == "UNION":
        out["has_union"] = True
    return out


def main():
    base = Path("/workspace/bench/ast-equiv")
    sources = {
        "ogsql": base / "ogsql_semantic.json",
        "sqlparser": base / "sqlparser_semantic.json",
        "pglast": base / "pglast_semantic.json",
        "jsqlparser": base / "jsqlparser_semantic.json",
    }
    all_facts = {p: load_facts(path) for p, path in sources.items()}

    # Print comparison table
    case_names = sorted(set.intersection(*[set(d.keys()) for d in all_facts.values()]))
    print(f"\n=== Cross-Parser Semantic Comparison (on {len(case_names)} canonical SQLs) ===\n")
    print(f"Legend: ✓ matches all parsers, ⚠ partial match (some parsers disagree), ✗ fails")

    summary = {
        "total": len(case_names),
        "all_agree": 0,
        "partial": 0,
        "fail": 0,
        "details": [],
    }

    for name in case_names:
        facts = {p: extract_key_facts(all_facts[p].get(name, {})) for p in sources}
        # Check stmt_type
        stmt_types = {p: f["stmt_type"] for p, f in facts.items()}
        # Check tables
        tables = {p: f["tables"] for p, f in facts.items()}
        # Check columns
        cols = {p: f["columns"] for p, f in facts.items()}
        # Check structural
        struct = {p: (f["has_join"], f["has_subquery"], f["has_cte"], f["has_window"]) for p, f in facts.items()}

        all_stmt_types = set(stmt_types.values())
        all_tables = set(tables.values())
        all_cols = set(cols.values())
        all_struct = set(struct.values())

        # Filter None
        non_null_stmt = {p: v for p, v in stmt_types.items() if v is not None}
        non_null_tables = {p: v for p, v in tables.items() if v}
        non_null_cols = {p: v for p, v in cols.items() if v}

        if len(non_null_stmt) == 0:
            verdict = "✗ ALL FAIL"
            summary["fail"] += 1
        elif len(all_stmt_types) == 1 and len(all_tables) <= 1 and len(all_cols) <= 1 and len(all_struct) == 1:
            verdict = "✓ ALL AGREE"
            summary["all_agree"] += 1
        else:
            verdict = "⚠ PARTIAL"
            summary["partial"] += 1

        print(f"  {verdict:14s} {name:32s}")
        print(f"    stmt_type: {stmt_types}")
        if len(all_tables) > 1:
            print(f"    tables:    {tables}")
        if len(all_cols) > 1:
            print(f"    columns:   {cols}")
        if len(all_struct) > 1:
            print(f"    struct:    {struct}")

        summary["details"].append({
            "case": name,
            "verdict": verdict,
            "stmt_types": stmt_types,
            "tables": tables,
            "columns": cols,
            "struct": struct,
        })

    print(f"\n=== Summary ===")
    print(f"  Total:        {summary['total']}")
    print(f"  All agree:    {summary['all_agree']} ({100*summary['all_agree']/summary['total']:.1f}%)")
    print(f"  Partial:      {summary['partial']} ({100*summary['partial']/summary['total']:.1f}%)")
    print(f"  Fail:         {summary['fail']} ({100*summary['fail']/summary['total']:.1f}%)")

    out_path = base / "semantic_comparison.json"
    with out_path.open("w") as f:
        json.dump(summary, f, indent=2)
    print(f"\nSaved {out_path}")


if __name__ == "__main__":
    main()
