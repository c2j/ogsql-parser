-- canonical_01_simple_select
SELECT id, name FROM users
-- canonical_02_where_eq
SELECT id, name FROM users WHERE id = 42
-- canonical_03_where_in
SELECT id, name FROM users WHERE status IN ('active', 'pending') AND age > 18
-- canonical_04_join
SELECT u.id, u.name, o.amount FROM users u INNER JOIN orders o ON u.id = o.user_id WHERE o.amount > 100
-- canonical_05_groupby_having
SELECT department, COUNT(*) AS cnt, AVG(salary) AS avg_sal FROM employees GROUP BY department HAVING COUNT(*) > 5
-- canonical_06_order_limit
SELECT id, name, created_at FROM users ORDER BY created_at DESC LIMIT 10
-- canonical_07_insert
INSERT INTO users (id, name, email, created_at) VALUES (1, 'alice', 'a@x.com', '2024-01-01 10:00:00')
-- canonical_08_update
UPDATE users SET name = 'bob', email = 'b@x.com' WHERE id = 1
-- canonical_09_delete
DELETE FROM users WHERE created_at < '2024-01-01' AND status = 'inactive'
-- canonical_10_cte
WITH active_users AS (SELECT id, name FROM users WHERE status = 'active') SELECT * FROM active_users WHERE name LIKE 'A%'
-- canonical_11_subquery
SELECT id, name FROM users WHERE id IN (SELECT user_id FROM orders WHERE amount > 1000)
-- canonical_12_window
SELECT id, name, department, salary, RANK() OVER (PARTITION BY department ORDER BY salary DESC) AS rnk FROM employees
-- canonical_13_union
SELECT id, name FROM users WHERE status = 'active' UNION SELECT id, name FROM admins WHERE level > 5
