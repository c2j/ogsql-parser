"""AST semantic fingerprint extraction.

Each parser produces a different AST (Rust enums, C protobuf, Java objects).
This module extracts a normalized "semantic fingerprint" from each parser's AST
and emits it as JSON, so we can compare across parsers.

The fingerprint is NOT a complete AST — it's the small set of features that
matter for query understanding:
  - statement type
  - target table(s) (with aliases)
  - projected columns (with aliases)
  - WHERE conditions (table.column, operator, value)
  - JOIN conditions (left, right, condition)
  - GROUP BY / HAVING columns
  - ORDER BY columns and direction
  - LIMIT / OFFSET
  - subquery/CTE references
  - for INSERT: columns and values
  - for UPDATE: SET columns and WHERE
  - for DELETE: WHERE
"""
import json
import re
from typing import Any, Dict, List, Optional, Tuple


# --- Helpers for parsing column references --------------------------------

COLUMN_RE = re.compile(r"^`?([A-Za-z_][A-Za-z0-9_]*)`?(?:\.([A-Za-z_`][A-Za-z0-9_`.`]*))?$")


def parse_colref(s: str) -> Tuple[Optional[str], Optional[str], str]:
    """Parse a column reference. Returns (table, column, original)."""
    if s is None:
        return (None, None, "")
    s = s.strip()
    # Strip backticks
    s_clean = s.replace("`", "")
    if "." in s_clean:
        parts = s_clean.split(".", 1)
        return (parts[0], parts[1], s)
    return (None, s_clean, s)


def normalize_value(v: Any) -> Any:
    """Normalize a value for comparison."""
    if v is None:
        return None
    if isinstance(v, (int, float, bool, str)):
        return v
    if isinstance(v, dict):
        return {k: normalize_value(val) for k, val in v.items()}
    if isinstance(v, list):
        return [normalize_value(x) for x in v]
    return str(v)


# --- ogsql-parser AST extraction (uses serde_json via JSON parse) --------

def ogsql_fingerprint(stmt_json: dict) -> dict:
    """Convert ogsql-parser JSON AST to a normalized fingerprint.

    ogsql-parser exposes serde-serialized AST. We use the string form from
    the JSON. For the fingerprint, we mostly need to know what tables, columns,
    operations exist - and we get that from the JSON's tagged enum names.
    """
    fp = {"parser": "ogsql", "ok": True}
    # The root statement has a single key like "Select", "Insert", etc.
    keys = [k for k in stmt_json.keys() if k not in ("source_location", "comments")]
    if not keys:
        fp["ok"] = False
        return fp
    stmt_type = keys[0]
    inner = stmt_json[stmt_type]
    fp["stmt_type"] = stmt_type.lower()

    # Extract tables and columns from inner
    fp["tables"] = extract_ogsql_tables(inner, stmt_type)
    fp["columns"] = extract_ogsql_columns(inner, stmt_type)
    fp["where"] = extract_ogsql_where(inner, stmt_type)
    fp["joins"] = extract_ogsql_joins(inner, stmt_type)
    fp["group_by"] = extract_ogsql_groupby(inner, stmt_type)
    fp["having"] = extract_ogsql_having(inner, stmt_type)
    fp["order_by"] = extract_ogsql_orderby(inner, stmt_type)
    fp["limit"] = extract_ogsql_limit(inner, stmt_type)
    fp["ctes"] = extract_ogsql_ctes(inner, stmt_type)
    return fp


def _walk_obj(obj, path=""):
    """Yield (path, dict) for each dict node in the AST, for manual extraction."""
    if isinstance(obj, dict):
        yield path, obj
        for k, v in obj.items():
            if isinstance(v, (dict, list)):
                yield from _walk_obj(v, f"{path}.{k}" if path else k)
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            if isinstance(v, (dict, list)):
                yield from _walk_obj(v, f"{path}[{i}]" if path else f"[{i}]")


def extract_ogsql_tables(inner, stmt_type):
    tables = []
    for path, node in _walk_obj(inner):
        if "TableRef" in node or "table_name" in node or "name" in node and "From" in path:
            name = node.get("name") or node.get("table_name")
            alias = node.get("alias")
            if name and isinstance(name, str) and "." in name:
                schema, _, tname = name.rpartition(".")
                tables.append({"schema": schema, "name": tname, "alias": alias})
            elif name and isinstance(name, str) and not name.startswith("__"):
                tables.append({"schema": None, "name": name, "alias": alias})
    # De-dup
    seen = set()
    out = []
    for t in tables:
        key = (t.get("schema"), t["name"], t.get("alias"))
        if key not in seen:
            seen.add(key)
            out.append(t)
    return out


def extract_ogsql_columns(inner, stmt_type):
    cols = []
    for path, node in _walk_obj(inner):
        # Heuristic: nodes with "name" and "ColumnRef" or path containing "projection"
        if "ColumnRef" in node or "column_name" in node:
            name = node.get("name") or node.get("column_name")
            alias = node.get("alias")
            if name:
                cols.append({"name": name, "alias": alias})
    return cols


def extract_ogsql_where(inner, stmt_type):
    # We rely on the fact that ogsql-parser outputs JsonValue for literals
    # Just look for the Where clause and report "exists"
    for path, node in _walk_obj(inner):
        if "Where" in path and "condition" in node:
            return {"present": True, "raw": str(node)[:200]}
    return {"present": False}


def extract_ogsql_joins(inner, stmt_type):
    joins = []
    for path, node in _walk_obj(inner):
        if "JoinClause" in node or "join_type" in node:
            joins.append({"type": node.get("join_type", "UNKNOWN"), "raw": str(node)[:150]})
    return joins


def extract_ogsql_groupby(inner, stmt_type):
    gb = []
    for path, node in _walk_obj(inner):
        if "GroupBy" in path and isinstance(node, list):
            gb.extend(str(x)[:80] for x in node)
    return gb


def extract_ogsql_having(inner, stmt_type):
    for path, node in _walk_obj(inner):
        if "Having" in path:
            return {"present": True, "raw": str(node)[:200]}
    return {"present": False}


def extract_ogsql_orderby(inner, stmt_type):
    ob = []
    for path, node in _walk_obj(inner):
        if "OrderBy" in path and isinstance(node, list):
            ob.extend(str(x)[:80] for x in node)
    return ob


def extract_ogsql_limit(inner, stmt_type):
    for path, node in _walk_obj(inner):
        if "Limit" in path and node:
            return {"raw": str(node)[:80]}
    return None


def extract_ogsql_ctes(inner, stmt_type):
    ctes = []
    for path, node in _walk_obj(inner):
        if "With" in path and "cte_name" in node:
            ctes.append({"name": node.get("cte_name")})
        elif "Cte" in path and "name" in node:
            ctes.append({"name": node.get("name")})
    return ctes


# --- Test driver ----------------------------------------------------------

def test_fingerprint_extraction():
    """Verify fingerprint extraction works on a simple case."""
    sample = {
        "Select": {
            "projection": [
                {"ExpressionWithAlias": {"expr": {"ColumnRef": {"name": "id"}}, "alias": None}},
                {"ExpressionWithAlias": {"expr": {"ColumnRef": {"name": "name"}}, "alias": None}},
            ],
            "from": {"TableRef": {"name": "users", "alias": None}},
            "where": None,
        }
    }
    fp = ogsql_fingerprint(sample)
    assert fp["stmt_type"] == "select"
    print("ogsql fingerprint test passed:", json.dumps(fp, indent=2, default=str))


if __name__ == "__main__":
    test_fingerprint_extraction()
