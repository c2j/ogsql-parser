"""ogsql-parser semantic extraction from its JSON AST.

ogsql-parser serializes its Rust AST as nested JSON objects. The structure is
consistent: each statement is a dict with one key naming the statement type
("Select", "Insert", "Update", "Delete"), whose value is the statement's data.
"""
import json
import os
import subprocess
import sys
import tempfile

OGSQL_BIN = "/workspace/bench/rust-bench/target/release/ogsql-ast-dump"


def colref_to_str(cr):
    """Convert an ogsql ColumnRef JSON node to a string."""
    if not isinstance(cr, dict):
        return None
    if "ColumnRef" in cr:
        return ".".join(cr["ColumnRef"])
    return None


def extract_where(node):
    if not node:
        return []
    out = []
    # BinaryOp node
    if isinstance(node, dict) and "BinaryOp" in node:
        b = node["BinaryOp"]
        left = colref_to_str(b.get("left"))
        op = b.get("op")
        right = b.get("right")
        if isinstance(right, dict) and "Literal" in right:
            v = right["Literal"]
            if isinstance(v, dict):
                if "Integer" in v:
                    right = v["Integer"]
                elif "String" in v:
                    right = v["String"]
                else:
                    right = list(v.values())[0] if v else None
            else:
                right = v
        if isinstance(right, dict) and "ColumnRef" in right:
            right = colref_to_str(right)
        out.append({"left": left, "op": op, "right": right})
    elif isinstance(node, dict) and "InSubquery" in node:
        out.append({"left": colref_to_str(node["InSubquery"].get("left")), "op": "IN", "right": "SUBQUERY"})
    elif isinstance(node, dict) and "Like" in node:
        out.append({"left": colref_to_str(node["Like"].get("left")), "op": "LIKE", "right": node["Like"].get("pattern")})
    elif isinstance(node, dict) and "InList" in node:
        il = node["InList"]
        vals = il.get("values", [])
        out.append({"left": colref_to_str(il.get("left")), "op": "IN", "right": [v for v in vals]})
    elif isinstance(node, dict) and "LogicalOp" in node:
        # AND / OR - just emit raw
        out.append({"raw": f"AND/OR:{json.dumps(node)[:60]}"})
    return out


def extract_select(stmt):
    return {
        "stmt_type": "SELECT",
        "tables": [t["Table"]["name"][0] if "Table" in t and t["Table"].get("name") else str(t)[:30]
                   for t in stmt.get("from", []) if isinstance(t, dict) and "Table" in t],
        "columns": [colref_to_str(e[0]) if isinstance(e, list) and e else (colref_to_str(e) if isinstance(e, dict) else str(e)[:30])
                    for tgt in stmt.get("targets", [])
                    for e in [tgt.get("Expr", [None, None])[0] if "Expr" in tgt else tgt]
                    ],
        "where": extract_where(stmt.get("where_clause")),
        "joins": [t["Table"]["name"][0] if "Table" in t and t["Table"].get("name") else str(t)[:30]
                  for t in stmt.get("from", []) if isinstance(t, dict) and "Join" in t],
        "group_by": [colref_to_str(g) if isinstance(g, dict) else str(g)[:30] for g in stmt.get("group_by", [])],
        "having": extract_where(stmt.get("having")),
        "order_by": [colref_to_str(o) if isinstance(o, dict) else str(o)[:30] for o in stmt.get("order_by", [])],
        "limit": stmt.get("limit", {}).get("Literal", {}).get("Integer") if stmt.get("limit") else None,
        "ctes": [cte.get("name") for cte in (stmt.get("with") or {}).get("ctes", []) if isinstance(cte, dict)] if isinstance(stmt.get("with"), dict) else [],
    }


def extract_insert(stmt):
    return {
        "stmt_type": "INSERT",
        "table": stmt.get("table", {}).get("Table", {}).get("name", [None])[0] if stmt.get("table") else None,
        "columns": stmt.get("columns", []),
    }


def extract_update(stmt):
    return {
        "stmt_type": "UPDATE",
        "table": stmt.get("table", {}).get("Table", {}).get("name", [None])[0] if stmt.get("table") else None,
        "where": extract_where(stmt.get("where_clause")),
    }


def extract_delete(stmt):
    return {
        "stmt_type": "DELETE",
        "table": stmt.get("table", {}).get("Table", {}).get("name", [None])[0] if stmt.get("table") else None,
        "where": extract_where(stmt.get("where_clause")),
    }


def parse_with_ogsql(sql):
    """Run ogsql-ast-dump binary and return the parsed JSON AST."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.sql', delete=False) as f:
        f.write(sql)
        path = f.name
    try:
        result = subprocess.run(
            [OGSQL_BIN, path], capture_output=True, timeout=5, text=True,
        )
        if result.returncode != 0:
            return None
        return json.loads(result.stdout)
    finally:
        os.unlink(path)


def main():
    input_path = sys.argv[1]
    output_path = sys.argv[2]
    cases = []
    with open(input_path) as f:
        for line in f:
            line = line.rstrip("\n")
            if not line.strip():
                continue
            tab = line.find("\t")
            if tab < 0:
                continue
            name = line[:tab]
            sql = line[tab + 1:]

            case = {"name": name, "sql": sql, "parse_ok": False, "facts": None, "error": None}
            try:
                ast = parse_with_ogsql(sql)
                if ast is None:
                    case["error"] = "Parse failed"
                else:
                    case["parse_ok"] = True
                    facts = []
                    for stmt_wrapper in ast:
                        # Each stmt_wrapper has a single key like "Select"
                        if not isinstance(stmt_wrapper, dict):
                            continue
                        stmt_type = list(stmt_wrapper.keys())[0]
                        inner = stmt_wrapper[stmt_type]
                        if stmt_type == "Select":
                            facts.append(extract_select(inner))
                        elif stmt_type == "Insert":
                            facts.append(extract_insert(inner))
                        elif stmt_type == "Update":
                            facts.append(extract_update(inner))
                        elif stmt_type == "Delete":
                            facts.append(extract_delete(inner))
                        else:
                            facts.append({"stmt_type": stmt_type})
                    case["facts"] = facts
            except Exception as e:
                case["error"] = f"{type(e).__name__}: {str(e)[:80]}"
            cases.append(case)

    with open(output_path, "w") as f:
        json.dump({"parser": "ogsql-parser 0.8.3 (semantic extraction)", "cases": cases}, f, indent=2)
    parse_ok = sum(1 for c in cases if c["parse_ok"])
    print(f"[ogsql-sem] parse: {parse_ok}/{len(cases)}")
    for c in cases:
        status = "OK" if c["parse_ok"] else "ERR"
        snippet = c.get("error") or json.dumps(c.get("facts"), default=str)[:80]
        print(f"  {c['name']:32s} [{status}]: {snippet}")


if __name__ == "__main__":
    main()
