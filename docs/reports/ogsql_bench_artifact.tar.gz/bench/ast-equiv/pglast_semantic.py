"""pglast semantic extraction: extract key facts (tables, columns, ops, filters)
from the namedtuple AST. No deparser needed.
"""
import json
import sys

import pglast
from pglast import ast
from pglast.ast import SelectStmt, InsertStmt, UpdateStmt, DeleteStmt, ColumnRef, A_Expr, A_Const, RangeVar, ResTarget


def colref_to_str(cr):
    """Convert ColumnRef to a string like 'table.column' or 'column'."""
    if not isinstance(cr, ColumnRef):
        return None
    fields = cr.fields
    parts = []
    for f in fields:
        if isinstance(f, ast.String):
            parts.append(f.sval)
    return ".".join(parts) if parts else None


def extract_where(node):
    """Extract WHERE conditions as a list of (left, op, right) triples."""
    if not node:
        return []
    if isinstance(node, A_Expr):
        op = "?"
        if node.name and isinstance(node.name[0], ast.String):
            op = node.name[0].sval
        left = colref_to_str(node.lexpr) if isinstance(node.lexpr, ColumnRef) else str(node.lexpr)[:30]
        right = colref_to_str(node.rexpr) if isinstance(node.rexpr, ColumnRef) else str(node.rexpr)[:30]
        if isinstance(node.rexpr, A_Const):
            if node.rexpr.isnull:
                right = "NULL"
            elif node.rexpr.val is not None:
                v = node.rexpr.val
                right = v.ival if hasattr(v, 'ival') else (v.fval if hasattr(v, 'fval') else (v.sval if hasattr(v, 'sval') else str(v)[:30]))
        # Detect subquery (SubLink)
        if isinstance(node.rexpr, ast.SubLink):
            right = "SUBQUERY"
        if isinstance(node.lexpr, ast.SubLink):
            left = "SUBQUERY"
        return [{"left": left, "op": op, "right": right}]
    return [{"raw": str(node)[:80]}]


def extract_select(stmt):
    return {
        "stmt_type": "SELECT",
        "tables": [str(rv.relname) for rv in (stmt.fromClause or []) if isinstance(rv, RangeVar)],
        "columns": [
            colref_to_str(rt.val) if isinstance(rt.val, ColumnRef) else str(rt.val)[:30]
            for rt in (stmt.targetList or []) if isinstance(rt, ResTarget)
        ],
        "where": extract_where(stmt.whereClause),
        "joins": [[f"JOIN:{rv.jointype.name}" for rv in (stmt.fromClause or []) if isinstance(rv, ast.JoinExpr)]],
        "group_by": [str(x)[:30] for x in (stmt.groupClause or [])],
        "having": extract_where(stmt.havingClause),
        "order_by": [str(x)[:30] for x in (stmt.sortClause or [])],
        "limit": stmt.limitCount.ival if stmt.limitCount and hasattr(stmt.limitCount, 'ival') else None,
        "ctes": [cte.ctename for cte in (stmt.withClause.ctes if stmt.withClause else [])] if hasattr(stmt, 'withClause') else [],
    }


def extract_insert(stmt):
    cols = []
    for c in (stmt.cols or []):
        if isinstance(c, ast.ResTarget):
            name = c.name
            if not name and isinstance(c.val, ColumnRef):
                name = colref_to_str(c.val)
            if name: cols.append(name)
    # Actually cols is list of ResTarget
    cols = []
    for c in (stmt.cols or []):
        if isinstance(c, ast.ResTarget):
            name = c.name
            if not name and isinstance(c.val, ColumnRef):
                name = colref_to_str(c.val)
            if name: cols.append(name)
    for c in (stmt.cols or []):
        if isinstance(c, ast.ResTarget) and c.name:
            cols.append(c.name)
    return {
        "stmt_type": "INSERT",
        "table": stmt.relation.relname if stmt.relation else None,
        "columns": cols,
    }


def extract_update(stmt):
    return {
        "stmt_type": "UPDATE",
        "table": stmt.relation.relname if stmt.relation else None,
        "where": extract_where(stmt.whereClause),
    }


def extract_delete(stmt):
    return {
        "stmt_type": "DELETE",
        "table": stmt.relation.relname if stmt.relation else None,
        "where": extract_where(stmt.whereClause),
    }


def main():
    input_path = sys.argv[1]
    output_path = sys.argv[2]
    cases = []
    with open(input_path) as f:
        for line in f:
            line = line.rstrip("\n")
            if not line.strip():
                continue
            tab = line.find("\t")
            if tab < 0:
                continue
            name = line[:tab]
            sql = line[tab + 1:]

            case = {
                "name": name, "sql": sql,
                "parse_ok": False, "facts": None, "error": None,
            }
            try:
                tree = pglast.parse_sql(sql)
                case["parse_ok"] = True
                stmts = []
                for raw in tree:
                    s = raw.stmt
                    if isinstance(s, SelectStmt):
                        stmts.append(extract_select(s))
                    elif isinstance(s, InsertStmt):
                        stmts.append(extract_insert(s))
                    elif isinstance(s, UpdateStmt):
                        stmts.append(extract_update(s))
                    elif isinstance(s, DeleteStmt):
                        stmts.append(extract_delete(s))
                    else:
                        stmts.append({"stmt_type": type(s).__name__})
                case["facts"] = stmts
            except Exception as e:
                case["error"] = f"{type(e).__name__}: {str(e)[:80]}"
            cases.append(case)

    with open(output_path, "w") as f:
        json.dump({"parser": "pglast 7.14 (semantic extraction)", "cases": cases}, f, indent=2)
    parse_ok = sum(1 for c in cases if c["parse_ok"])
    print(f"[pglast-sem] parse: {parse_ok}/{len(cases)}")
    for c in cases:
        status = "OK" if c["parse_ok"] else "ERR"
        snippet = c.get("error") or json.dumps(c.get("facts"), default=str)[:80]
        print(f"  {c['name']:32s} [{status}]: {snippet}")


if __name__ == "__main__":
    main()
