"""Stress test: extreme SQL inputs to expose the behavior of each parser at the edges.

Includes:
  - Very long single-statement INSERT (10K, 100K rows)
  - Deeply nested CTE (20 levels)
  - Very wide SELECT (200 columns)
  - Many joined tables (30-table join)
  - Pathological identifier (very long string)
  - Empty / whitespace-only / single-char inputs
"""
import json
import time

import pglast

CASES = {
    "long_insert_1k": None,  # filled below
    "long_insert_10k": None,
    "deeply_nested_cte_20": None,
    "wide_select_200cols": None,
    "many_joined_tables_30": None,
    "long_identifier_1k": None,
    "empty_input": "",
    "whitespace_only": "   \n\t  \n",
    "single_semicolon": ";",
    "single_token": "SELECT",
    "unterminated_string": "SELECT 'abc",
    "unterminated_comment": "SELECT /* abc",
    "valid_trivial": "SELECT 1",
    "valid_minimal": "SELECT a FROM b",
    "deeper_nesting": None,  # filled below
}

# Build 1k INSERT
rows_1k = ", ".join(f"({i}, 'name_{i}_{'x' * 20}', {i * 1.5})" for i in range(1000))
CASES["long_insert_1k"] = f"INSERT INTO t (id, name, val) VALUES {rows_1k};"

# Build 10k INSERT
rows_10k = ", ".join(f"({i}, 'n{i}')" for i in range(10_000))
CASES["long_insert_10k"] = f"INSERT INTO t (id, name) VALUES {rows_10k};"

# Deeply nested CTE
cte = "SELECT 1 AS x"
for i in range(20):
    cte = f"WITH c{i} AS ({cte}) SELECT * FROM c{i}"
CASES["deeply_nested_cte_20"] = cte

# Wide SELECT
cols = ", ".join(f"col_{i} AS c{i}" for i in range(200))
CASES["wide_select_200cols"] = f"SELECT {cols} FROM t"

# Many joined tables
joins = "t1"
for i in range(2, 31):
    joins += f" JOIN t{i} ON t{i-1}.id = t{i}.id"
CASES["many_joined_tables_30"] = f"SELECT t1.id FROM {joins}"

# Long identifier
CASES["long_identifier_1k"] = f"SELECT {'a' * 1000} FROM t"

# Deeper nesting (50 levels of subquery)
inner = "SELECT 1"
for i in range(50):
    inner = f"SELECT * FROM ({inner}) sub_{i}"
CASES["deeper_nesting"] = inner

ITERS = max(1, 200 // 1)  # at most 200 iters per case for huge inputs

results = {}
for name, sql in CASES.items():
    sql_len = len(sql) if sql else 0
    # Determine iterations: fewer for huge inputs
    if sql_len > 50_000:
        iters = 10
    elif sql_len > 10_000:
        iters = 50
    elif sql_len > 1000:
        iters = 200
    else:
        iters = 1000

    lats = []
    ok = True
    err = None
    for _ in range(iters):
        t0 = time.perf_counter_ns()
        try:
            pglast.parse_sql(sql) if sql else pglast.parse_sql("")
        except Exception as e:
            ok = False
            err = f"{type(e).__name__}: {str(e)[:80]}"
        lats.append((time.perf_counter_ns() - t0) / 1000.0)  # us
    lats.sort()
    med = lats[len(lats) // 2]
    p95_idx = int(0.95 * (len(lats) - 1))
    p95 = lats[min(p95_idx, len(lats) - 1)]
    mx = lats[-1]
    results[name] = {
        "sql_len": sql_len,
        "iters": iters,
        "ok": ok,
        "err": err,
        "median_us": med,
        "p95_us": p95,
        "max_us": mx,
        "throughput_qps": iters / (sum(lats) / 1_000_000.0),
    }
    print(f"  {name:32s} (len={sql_len:6d}, iters={iters:4d}): median={med:8.1f}us, p95={p95:8.1f}us, max={mx:8.1f}us {'OK' if ok else 'ERR: ' + err[:60]}")

with open('/workspace/bench/results/pglast_stress.json', 'w') as f:
    json.dump({"parser": "pglast 7.14 (libpg_query)", "results": results}, f, indent=2)
print(f"\nSaved /workspace/bench/results/pglast_stress.json")
