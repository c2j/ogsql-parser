// JSqlParser benchmark - mirrors the Rust benches.
// Reads TSV corpus (category<TAB>sql) and measures parsing performance.

import java.io.*;
import java.nio.file.*;
import java.util.*;
import net.sf.jsqlparser.parser.CCJSqlParserUtil;
import net.sf.jsqlparser.statement.Statement;

public class JsqlBench {
    static class CategoryStats {
        int n = 0;
        int success = 0;
        List<Double> latencies = new ArrayList<>();
    }

    static double percentile(List<Double> sorted, double p) {
        int idx = (int) Math.round((p / 100.0) * (sorted.size() - 1));
        return sorted.get(Math.min(idx, sorted.size() - 1));
    }

    static String readRssKb() {
        try {
            for (String line : Files.readAllLines(Paths.get("/proc/self/status"))) {
                if (line.startsWith("VmRSS:")) {
                    String[] parts = line.trim().split("\\s+");
                    return parts[1];
                }
            }
        } catch (Exception e) {}
        return "0";
    }

    static List<String[]> loadCorpus(String path) throws IOException {
        List<String[]> items = new ArrayList<>();
        for (String line : Files.readAllLines(Paths.get(path))) {
            if (line.isEmpty()) continue;
            int tab = line.indexOf('\t');
            if (tab < 0) continue;
            String cat = line.substring(0, tab);
            String sql = line.substring(tab + 1);
            items.add(new String[]{cat, sql});
        }
        return items;
    }

    public static void main(String[] args) throws Exception {
        if (args.length < 4) {
            System.err.println("Usage: JsqlBench <corpus.tsv> <iterations> <output.json> <mode: full|large|stress>");
            System.exit(1);
        }
        String corpusPath = args[0];
        int iterations = Integer.parseInt(args[1]);
        String outputPath = args[2];
        String mode = args[3];

        List<String[]> corpus = loadCorpus(corpusPath);
        System.err.printf("[jsqlparser] loaded %d statements (%d iterations each, mode=%s)%n",
            corpus.size(), iterations, mode);

        // Warmup
        int warmup = Math.min(50, corpus.size());
        for (int i = 0; i < warmup; i++) {
            String[] e = corpus.get(i);
            try { CCJSqlParserUtil.parse(e[1]); } catch (Exception ex) {}
        }
        // Force JVM JIT to compile the hot path
        for (int rep = 0; rep < 5; rep++) {
            for (int i = 0; i < warmup; i++) {
                String[] e = corpus.get(i);
                try { CCJSqlParserUtil.parse(e[1]); } catch (Exception ex) {}
            }
        }
        System.gc();

        long memBefore = Long.parseLong(readRssKb());
        long tStart = System.nanoTime();

        Map<String, CategoryStats> byCat = new LinkedHashMap<>();
        int successCount = 0;
        int errorCount = 0;
        Map<String, Integer> errorsByType = new LinkedHashMap<>();
        List<Double> allLatencies = new ArrayList<>(corpus.size());

        for (String[] entry : corpus) {
            String cat = entry[0];
            String sql = entry[1];
            List<Double> lats = new ArrayList<>(iterations);
            boolean ok = true;
            String errKind = "";
            for (int it = 0; it < iterations; it++) {
                long t0 = System.nanoTime();
                try {
                    Statement st = CCJSqlParserUtil.parse(sql);
                    if (st == null) { ok = false; errKind = "NullStatement"; }
                } catch (Throwable e) {
                    ok = false;
                    String name = e.getClass().getSimpleName();
                    String msg = e.getMessage() == null ? "" : e.getMessage();
                    int newline = msg.indexOf('\n');
                    if (newline > 0) msg = msg.substring(0, newline);
                    if (msg.length() > 60) msg = msg.substring(0, 60);
                    errKind = name + ":" + msg;
                }
                lats.add((System.nanoTime() - t0) / 1000.0);
            }
            Collections.sort(lats);
            double median = lats.get(lats.size() / 2);
            allLatencies.add(median);
            if (ok) successCount++;
            else { errorCount++; errorsByType.merge(errKind, 1, Integer::sum); }
            CategoryStats s = byCat.computeIfAbsent(cat, k -> new CategoryStats());
            s.n++;
            s.success += ok ? 1 : 0;
            s.latencies.add(median);
        }

        long elapsedNs = System.nanoTime() - tStart;
        long memAfter = Long.parseLong(readRssKb());
        double elapsedSec = elapsedNs / 1e9;
        long totalQueries = (long) corpus.size() * iterations;
        double throughput = totalQueries / elapsedSec;

        Collections.sort(allLatencies);
        double median = percentile(allLatencies, 50);
        double p95 = percentile(allLatencies, 95);
        double p99 = percentile(allLatencies, 99);
        double min = allLatencies.get(0);
        double max = allLatencies.get(allLatencies.size() - 1);
        double mean = 0;
        for (double v : allLatencies) mean += v;
        mean /= allLatencies.size();

        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"parser\": \"JSqlParser 5.3 (Java, multi-dialect)\",\n");
        sb.append("  \"corpus_size\": ").append(corpus.size()).append(",\n");
        sb.append("  \"iterations\": ").append(iterations).append(",\n");
        sb.append("  \"total_queries\": ").append(totalQueries).append(",\n");
        sb.append(String.format(java.util.Locale.ROOT, "  \"elapsed_sec\": %.6f,%n", elapsedSec));
        sb.append(String.format(java.util.Locale.ROOT, "  \"throughput_qps\": %.2f,%n", throughput));
        sb.append("  \"memory_kb_before\": ").append(memBefore).append(",\n");
        sb.append("  \"memory_kb_after\": ").append(memAfter).append(",\n");
        sb.append("  \"success_count\": ").append(successCount).append(",\n");
        sb.append("  \"error_count\": ").append(errorCount).append(",\n");

        // errors_by_type
        sb.append("  \"errors_by_type\": {");
        boolean first = true;
        for (Map.Entry<String, Integer> e : errorsByType.entrySet()) {
            if (!first) sb.append(",");
            first = false;
            sb.append("\"").append(esc(e.getKey())).append("\":").append(e.getValue());
        }
        sb.append("},\n");

        // overall latency
        sb.append("  \"overall_latency_us\": {");
        sb.append(String.format(java.util.Locale.ROOT,
            "\"median\":%.2f,\"mean\":%.2f,\"p95\":%.2f,\"p99\":%.2f,\"min\":%.2f,\"max\":%.2f",
            median, mean, p95, p99, min, max));
        sb.append("},\n");

        // by_category
        sb.append("  \"by_category\": {\n");
        first = true;
        for (Map.Entry<String, CategoryStats> e : byCat.entrySet()) {
            if (!first) sb.append(",\n");
            first = false;
            CategoryStats s = e.getValue();
            Collections.sort(s.latencies);
            double catMed = percentile(s.latencies, 50);
            double catMean = 0;
            for (double v : s.latencies) catMean += v;
            catMean /= s.latencies.size();
            sb.append("    \"").append(esc(e.getKey())).append("\": {");
            sb.append("\"n\":").append(s.n);
            sb.append(",\"success\":").append(s.success);
            sb.append(String.format(java.util.Locale.ROOT, ",\"success_rate\":%.4f", (double)s.success/s.n));
            sb.append(String.format(java.util.Locale.ROOT, ",\"median_latency_us\":%.2f", catMed));
            sb.append(String.format(java.util.Locale.ROOT, ",\"mean_latency_us\":%.2f", catMean));
            sb.append("}");
        }
        sb.append("\n  }\n");
        sb.append("}\n");

        Files.writeString(Paths.get(outputPath), sb.toString());
        System.err.printf("[jsqlparser] done: %.0f q/s, success %d/%d, mem %d -> %d KB%n",
            throughput, successCount, corpus.size(), memBefore, memAfter);
        System.err.printf("[jsqlparser] median: %.2f us, p99: %.2f us%n", median, p99);
    }

    static String esc(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
