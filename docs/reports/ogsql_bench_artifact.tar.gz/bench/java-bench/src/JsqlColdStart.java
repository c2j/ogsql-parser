// JSqlParser cold-start benchmark - measures JVM startup + first parse.
import java.io.*;
import java.nio.file.*;
import java.util.*;
import net.sf.jsqlparser.parser.CCJSqlParserUtil;

public class JsqlColdStart {
    public static void main(String[] args) throws Exception {
        int n = 20;
        // write a temp corpus
        Path tmp = Files.createTempFile("jsql_cold_", ".tsv");
        Files.writeString(tmp, "DQL\tSELECT id, name FROM users WHERE status = 'active' AND age > 18 ORDER BY created_at DESC LIMIT 100");
        Path out = Files.createTempFile("jsql_cold_out_", ".json");

        List<Long> latsMs = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            long t0 = System.nanoTime();
            // Spawn a fresh JVM
            ProcessBuilder pb = new ProcessBuilder(
                "java", "-cp", System.getProperty("java.class.path"), "JsqlBench",
                tmp.toString(), "1", out.toString(), "full"
            );
            pb.inheritIO();
            Process p = pb.start();
            int code = p.waitFor();
            if (code != 0) {
                System.err.println("Iteration " + i + " failed with code " + code);
                continue;
            }
            long elapsed = System.nanoTime() - t0;
            latsMs.add(elapsed / 1_000_000L);
        }
        Files.deleteIfExists(tmp);
        Files.deleteIfExists(out);

        Collections.sort(latsMs);
        long med = latsMs.get(latsMs.size() / 2);
        long mean = 0;
        for (long l : latsMs) mean += l;
        mean /= latsMs.size();
        long p95 = latsMs.get((int)(0.95 * (latsMs.size() - 1)));
        long mn = latsMs.get(0);
        long mx = latsMs.get(latsMs.size() - 1);
        System.out.printf("[jsqlparser-cold] N=%d, min=%dms, median=%dms, p95=%dms, max=%dms, mean=%dms%n",
            latsMs.size(), mn, med, p95, mx, mean);
    }
}
