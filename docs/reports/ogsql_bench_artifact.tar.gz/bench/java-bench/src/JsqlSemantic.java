// JSqlParser semantic extraction: extract key facts from Java AST objects.
import java.io.*;
import java.nio.file.*;
import java.util.*;
import net.sf.jsqlparser.parser.CCJSqlParserUtil;
import net.sf.jsqlparser.statement.Statement;
import net.sf.jsqlparser.statement.select.*;
import net.sf.jsqlparser.statement.insert.Insert;
import net.sf.jsqlparser.statement.update.Update;
import net.sf.jsqlparser.statement.delete.Delete;
import net.sf.jsqlparser.schema.Table;
import net.sf.jsqlparser.statement.select.PlainSelect;
import net.sf.jsqlparser.expression.*;

public class JsqlSemantic {
    static List<String> extractTables(PlainSelect ps) {
        List<String> tables = new ArrayList<>();
        if (ps.getFromItem() != null) {
            tables.add(ps.getFromItem().toString().split(" ")[0]);
        }
        if (ps.getJoins() != null) {
            for (Join j : ps.getJoins()) {
                tables.add(j.toString().split(" ")[0]);
            }
        }
        return tables;
    }

    static List<String> extractColumns(PlainSelect ps) {
        List<String> cols = new ArrayList<>();
        if (ps.getSelectItems() != null) {
            for (SelectItem si : ps.getSelectItems()) {
                cols.add(si.toString());
            }
        }
        return cols;
    }

    static List<Map<String, Object>> extractWhere(Expression expr) {
        List<Map<String, Object>> out = new ArrayList<>();
        if (expr == null) return out;
        // Try to extract simple comparisons
        out.add(new LinkedHashMap<String, Object>() {{
            put("raw", expr.toString());
        }});
        return out;
    }

    public static void main(String[] args) throws Exception {
        String inputPath = args[0];
        String outputPath = args[1];

        StringBuilder sb = new StringBuilder();
        sb.append("{\n  \"parser\": \"JSqlParser 5.3 (semantic extraction)\",\n  \"cases\": [\n");
        boolean first = true;

        for (String line : Files.readAllLines(Paths.get(inputPath))) {
            if (line.isEmpty()) continue;
            int tab = line.indexOf('\t');
            if (tab < 0) continue;
            String name = line.substring(0, tab);
            String sql = line.substring(tab + 1);

            Map<String, Object> c = new LinkedHashMap<>();
            c.put("name", name);
            c.put("sql", sql);
            c.put("parse_ok", false);
            c.put("facts", null);
            c.put("error", null);

            try {
                Statement stmt = CCJSqlParserUtil.parse(sql);
                c.put("parse_ok", true);
                List<Map<String, Object>> facts = new ArrayList<>();
                if (stmt instanceof Select) {
                    Select sel = (Select) stmt;
                    PlainSelect ps = sel.getPlainSelect();
                    if (ps != null) {
                        Map<String, Object> f = new LinkedHashMap<>();
                        f.put("stmt_type", "SELECT");
                        f.put("tables", extractTables(ps));
                        f.put("columns", extractColumns(ps));
                        f.put("where", extractWhere(ps.getWhere()));
                        f.put("joins", ps.getJoins() == null ? new ArrayList<>() :
                            java.util.Arrays.asList(ps.getJoins().toString().split(",")));
                        f.put("group_by", ps.getGroupBy() == null ? new ArrayList<>() :
                            java.util.Arrays.asList(ps.getGroupBy().toString().split(",")));
                        f.put("having", extractWhere(ps.getHaving()));
                        f.put("order_by", ps.getOrderByElements() == null ? new ArrayList<>() :
                            java.util.Arrays.asList(ps.getOrderByElements().toString().split(",")));
                        f.put("limit", ps.getLimit() == null ? null : ps.getLimit().toString());
                        facts.add(f);
                    } else if (sel.getSetOperationList() != null) {
                        // UNION etc.
                        Map<String, Object> f = new LinkedHashMap<>();
                        f.put("stmt_type", "UNION");
                        f.put("selects", sel.getSetOperationList().getSelects().size());
                        facts.add(f);
                    }
                } else if (stmt instanceof Insert) {
                    Insert ins = (Insert) stmt;
                    Map<String, Object> f = new LinkedHashMap<>();
                    f.put("stmt_type", "INSERT");
                    f.put("table", ins.getTable().getName());
                    f.put("columns", ins.getColumns() == null ? new ArrayList<>() : ins.getColumns());
                    facts.add(f);
                } else if (stmt instanceof Update) {
                    Update upd = (Update) stmt;
                    Map<String, Object> f = new LinkedHashMap<>();
                    f.put("stmt_type", "UPDATE");
                    f.put("table", upd.getTable().getName());
                    f.put("where", extractWhere(upd.getWhere()));
                    facts.add(f);
                } else if (stmt instanceof Delete) {
                    Delete del = (Delete) stmt;
                    Map<String, Object> f = new LinkedHashMap<>();
                    f.put("stmt_type", "DELETE");
                    f.put("table", del.getTable().getName());
                    f.put("where", extractWhere(del.getWhere()));
                    facts.add(f);
                } else {
                    facts.add(new LinkedHashMap<String, Object>() {{
                        put("stmt_type", stmt.getClass().getSimpleName());
                    }});
                }
                c.put("facts", facts);
            } catch (Throwable t) {
                c.put("error", t.getClass().getSimpleName() + ": " +
                    (t.getMessage() == null ? "" : t.getMessage().substring(0, Math.min(80, t.getMessage().length()))));
            }

            // Serialize this case
            if (!first) sb.append(",\n");
            first = false;
            sb.append("    {");
            sb.append("\"name\":\"").append(esc(name)).append("\",");
            sb.append("\"sql\":\"").append(esc(sql)).append("\",");
            sb.append("\"parse_ok\":").append(c.get("parse_ok")).append(",");
            sb.append("\"facts\":");
            appendFacts(sb, c.get("facts"));
            sb.append(",\"error\":").append(c.get("error") == null ? "null" :
                "\"" + esc(c.get("error").toString()) + "\"");
            sb.append("}");
        }
        sb.append("\n  ]\n}\n");
        Files.writeString(Paths.get(outputPath), sb.toString());
        System.out.println("Wrote " + outputPath);
    }

    @SuppressWarnings("unchecked")
    static void appendFacts(StringBuilder sb, Object facts) {
        if (facts == null) { sb.append("null"); return; }
        sb.append("[");
        boolean firstInner = true;
        for (Map<String, Object> f : (List<Map<String, Object>>) facts) {
            if (!firstInner) sb.append(",");
            firstInner = false;
            sb.append("{");
            boolean firstKV = true;
            for (Map.Entry<String, Object> e : f.entrySet()) {
                if (!firstKV) sb.append(",");
                firstKV = false;
                sb.append("\"").append(esc(e.getKey())).append("\":");
                appendValue(sb, e.getValue());
            }
            sb.append("}");
        }
        sb.append("]");
    }

    static void appendValue(StringBuilder sb, Object v) {
        if (v == null) { sb.append("null"); return; }
        if (v instanceof Number || v instanceof Boolean) { sb.append(v); return; }
        if (v instanceof List) {
            sb.append("[");
            boolean first = true;
            for (Object x : (List<?>) v) {
                if (!first) sb.append(",");
                first = false;
                appendValue(sb, x);
            }
            sb.append("]");
            return;
        }
        sb.append("\"").append(esc(v.toString())).append("\"");
    }

    static String esc(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ").replace("\r", "");
    }
}
