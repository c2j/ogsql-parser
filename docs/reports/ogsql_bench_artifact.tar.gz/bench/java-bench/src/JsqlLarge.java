// JSqlParser targeted large-statement benchmark.
// Mirrors the Rust large_stmt_bench.rs.
import java.io.*;
import java.nio.file.*;
import java.util.*;
import net.sf.jsqlparser.parser.CCJSqlParserUtil;
import net.sf.jsqlparser.statement.Statement;

public class JsqlLarge {
    static class Query {
        String name;
        String sql;
        Query(String n, String s) { name = n; sql = s; }
    }

    static double percentile(List<Double> sorted, double p) {
        int idx = (int) Math.round((p / 100.0) * (sorted.size() - 1));
        return sorted.get(Math.min(idx, sorted.size() - 1));
    }

    public static void main(String[] args) throws Exception {
        List<Query> queries = new ArrayList<>();
        queries.add(new Query("simple_select", "SELECT id, name FROM users WHERE status = 'active'"));
        queries.add(new Query("join_3way", "SELECT u.id, u.name, COUNT(o.id) FROM users u JOIN orders o ON u.id = o.user_id JOIN products p ON o.product_id = p.id WHERE u.created_at > '2024-01-01' GROUP BY u.id, u.name HAVING COUNT(o.id) > 5"));
        queries.add(new Query("cte_chain", "WITH regional_sales AS (SELECT region, SUM(amount) AS total_sales FROM orders WHERE order_date >= '2024-01-01' GROUP BY region), top_regions AS (SELECT region FROM regional_sales WHERE total_sales > 1000000) SELECT r.region, r.total_sales, (SELECT COUNT(*) FROM customers c WHERE c.region = r.region) AS customer_count FROM regional_sales r WHERE r.region IN (SELECT region FROM top_regions) ORDER BY r.total_sales DESC LIMIT 10"));
        queries.add(new Query("window_fn", "SELECT id, name, department, salary, RANK() OVER (PARTITION BY department ORDER BY salary DESC) AS dept_rank, SUM(salary) OVER (PARTITION BY department) AS dept_total FROM employees"));
        queries.add(new Query("ddl_create_table", "CREATE TABLE orders (id BIGINT NOT NULL, user_id BIGINT NOT NULL, product_id BIGINT NOT NULL, amount DECIMAL(10,2) NOT NULL, status VARCHAR(20) NOT NULL DEFAULT 'pending', created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id), FOREIGN KEY (user_id) REFERENCES users(id), INDEX idx_status (status), INDEX idx_created (created_at))"));
        queries.add(new Query("bulk_insert_10", "INSERT INTO t (id, name, value) VALUES (1, 'a', 100), (2, 'b', 200), (3, 'c', 300), (4, 'd', 400), (5, 'e', 500), (6, 'f', 600), (7, 'g', 700), (8, 'h', 800), (9, 'i', 900), (10, 'j', 1000)"));
        queries.add(new Query("plpgsql_function", "CREATE OR REPLACE FUNCTION update_user_stats(p_user_id BIGINT) RETURNS VOID AS $$ BEGIN UPDATE users SET last_active = NOW() WHERE id = p_user_id; INSERT INTO user_stats (user_id, login_count, last_login) VALUES (p_user_id, 1, NOW()) ON CONFLICT (user_id) DO UPDATE SET login_count = user_stats.login_count + 1, last_login = NOW(); END; $$ LANGUAGE plpgsql"));

        int iters = 5000;  // fewer than Rust's 10k because JVM is slower
        System.err.printf("[jsqlparser-large] running %d queries x %d iters%n", queries.size(), iters);

        StringBuilder sb = new StringBuilder();
        sb.append("{\n  \"parser\": \"JSqlParser 5.3 (Java, multi-dialect)\",\n  \"per_query\": [\n");
        boolean first = true;

        for (Query q : queries) {
            // warmup
            for (int i = 0; i < 200; i++) {
                try { CCJSqlParserUtil.parse(q.sql); } catch (Exception e) {}
            }

            List<Double> lats = new ArrayList<>(iters);
            boolean ok = true;
            String errMsg = null;
            for (int i = 0; i < iters; i++) {
                long t0 = System.nanoTime();
                try {
                    Statement s = CCJSqlParserUtil.parse(q.sql);
                    if (s == null) { ok = false; errMsg = "NullStatement"; }
                } catch (Throwable e) {
                    ok = false;
                    errMsg = e.getClass().getSimpleName();
                }
                lats.add((System.nanoTime() - t0) / 1000.0);
            }
            Collections.sort(lats);
            double med = lats.get(iters / 2);
            double p95 = percentile(lats, 95.0);
            double totalSec = 0;
            for (double v : lats) totalSec += v;
            totalSec /= 1_000_000.0;
            double qps = iters / totalSec;

            System.err.printf("  %s: median=%.2fus, p95=%.2fus, qps=%.0f %s%n",
                q.name, med, p95, qps, ok ? "OK" : ("ERR: " + errMsg));

            if (!first) sb.append(",\n");
            first = false;
            sb.append("    {\n");
            sb.append("      \"name\": \"").append(q.name).append("\",\n");
            sb.append("      \"sql\": \"").append(q.sql.replace("\"", "\\\"")).append("\",\n");
            sb.append("      \"sql_len\": ").append(q.sql.length()).append(",\n");
            sb.append("      \"iters\": ").append(iters).append(",\n");
            sb.append(String.format(java.util.Locale.ROOT, "      \"median_us\": %.2f,%n", med));
            sb.append(String.format(java.util.Locale.ROOT, "      \"p95_us\": %.2f,%n", p95));
            sb.append(String.format(java.util.Locale.ROOT, "      \"throughput_qps\": %.2f,%n", qps));
            sb.append("      \"ok\": ").append(ok).append(",\n");
            sb.append("      \"err\": ").append(errMsg == null ? "null" : "\"" + esc(errMsg) + "\"").append("\n");
            sb.append("    }");
        }
        sb.append("\n  ]\n}\n");

        Files.writeString(Paths.get(args[0]), sb.toString());
        System.err.println("Wrote " + args[0]);
    }

    static String esc(String s) { return s.replace("\\", "\\\\").replace("\"", "\\\""); }
}
