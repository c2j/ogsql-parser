// JSqlParser round-trip test: parse → toString() → compare with original.
import java.io.*;
import java.nio.file.*;
import java.util.*;
import net.sf.jsqlparser.parser.CCJSqlParserUtil;
import net.sf.jsqlparser.statement.Statement;
import net.sf.jsqlparser.statement.select.PlainSelect;
import net.sf.jsqlparser.statement.select.Select;

public class JsqlRoundtrip {
    static String normalize(String s) {
        s = s.replaceAll("\\s+", " ").trim();
        if (s.endsWith(";")) s = s.substring(0, s.length() - 1).trim();
        return s;
    }

    public static void main(String[] args) throws Exception {
        String inputPath = args[0];
        String outputPath = args[1];

        List<Map<String, Object>> cases = new ArrayList<>();

        for (String line : Files.readAllLines(Paths.get(inputPath))) {
            if (line.isEmpty()) continue;
            int tab = line.indexOf('\t');
            if (tab < 0) continue;
            String name = line.substring(0, tab);
            String sql = line.substring(tab + 1);

            Map<String, Object> c = new LinkedHashMap<>();
            c.put("name", name);
            c.put("sql", sql);
            c.put("parse_ok", false);
            c.put("deparse_ok", false);
            c.put("deparsed", null);
            c.put("error", null);

            try {
                Statement stmt = CCJSqlParserUtil.parse(sql);
                c.put("parse_ok", true);
                String deparsed = stmt.toString();
                c.put("deparse_ok", true);
                c.put("deparsed", deparsed);
            } catch (Throwable t) {
                c.put("error", t.getClass().getSimpleName() + ": " +
                    (t.getMessage() == null ? "" : t.getMessage().substring(0, Math.min(80, t.getMessage().length()))));
            }
            cases.add(c);
        }

        // Build JSON
        StringBuilder sb = new StringBuilder();
        sb.append("{\n  \"parser\": \"JSqlParser 5.3 (Java, toString deparse)\",\n  \"cases\": [\n");
        boolean first = true;
        for (Map<String, Object> c : cases) {
            if (!first) sb.append(",\n");
            first = false;
            sb.append("    {");
            sb.append("\"name\":\"").append(esc(c.get("name").toString())).append("\",");
            sb.append("\"sql\":\"").append(esc(c.get("sql").toString())).append("\",");
            sb.append("\"parse_ok\":").append(c.get("parse_ok")).append(",");
            sb.append("\"deparse_ok\":").append(c.get("deparse_ok")).append(",");
            sb.append("\"deparsed\":").append(c.get("deparsed") == null ? "null" :
                "\"" + esc(c.get("deparsed").toString()) + "\"").append(",");
            sb.append("\"error\":").append(c.get("error") == null ? "null" :
                "\"" + esc(c.get("error").toString()) + "\"");
            sb.append("}");
        }
        sb.append("\n  ]\n}\n");
        Files.writeString(Paths.get(outputPath), sb.toString());

        int parseOk = 0, rtOk = 0, identical = 0;
        for (Map<String, Object> c : cases) {
            if ((Boolean) c.get("parse_ok")) parseOk++;
            if ((Boolean) c.get("deparse_ok")) rtOk++;
            if ((Boolean) c.get("deparse_ok") && c.get("deparsed") != null
                && normalize(c.get("deparsed").toString()).equals(normalize(c.get("sql").toString()))) {
                identical++;
            }
        }
        System.out.printf("[jsqlparser-rt] parse: %d/%d, deparse: %d/%d, round-trip identical: %d/%d%n",
            parseOk, cases.size(), rtOk, cases.size(), identical, cases.size());
        for (Map<String, Object> c : cases) {
            String status;
            if (!(Boolean) c.get("parse_ok")) status = "PARSE_ERR";
            else if (!(Boolean) c.get("deparse_ok")) status = "DEPARSE_ERR";
            else if (c.get("deparsed") != null &&
                     normalize(c.get("deparsed").toString()).equals(normalize(c.get("sql").toString())))
                status = "OK";
            else status = "DIFF";
            String snippet = (c.get("deparsed") != null ? c.get("deparsed").toString() :
                (c.get("error") != null ? c.get("error").toString() : ""));
            if (snippet.length() > 80) snippet = snippet.substring(0, 80);
            System.out.printf("  %-32s [%s]: %s%n", c.get("name"), status, snippet);
        }
    }

    static String esc(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ");
    }
}
