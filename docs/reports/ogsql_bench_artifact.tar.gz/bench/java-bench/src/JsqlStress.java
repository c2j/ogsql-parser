// JSqlParser stress test - mirrors Rust stress_bench.rs.
import java.io.*;
import java.nio.file.*;
import java.util.*;
import net.sf.jsqlparser.parser.CCJSqlParserUtil;
import net.sf.jsqlparser.statement.Statement;

public class JsqlStress {
    static double percentile(List<Double> sorted, double p) {
        int idx = (int) Math.round((p / 100.0) * (sorted.size() - 1));
        return sorted.get(Math.min(idx, sorted.size() - 1));
    }

    static Map<String, String> buildCases() {
        Map<String, String> cases = new LinkedHashMap<>();
        // Long INSERT 1k
        StringBuilder sb = new StringBuilder("INSERT INTO t (id, name, val) VALUES ");
        for (int i = 0; i < 1000; i++) {
            if (i > 0) sb.append(", ");
            sb.append("(").append(i).append(", 'name_").append(i).append("_").append("x".repeat(20)).append("', ").append(i * 1.5).append(")");
        }
        sb.append(";");
        cases.put("long_insert_1k", sb.toString());

        // Long INSERT 10k
        sb = new StringBuilder("INSERT INTO t (id, name) VALUES ");
        for (int i = 0; i < 10_000; i++) {
            if (i > 0) sb.append(", ");
            sb.append("(").append(i).append(", 'n").append(i).append("')");
        }
        sb.append(";");
        cases.put("long_insert_10k", sb.toString());

        // Deeply nested CTE 20
        String cte = "SELECT 1 AS x";
        for (int i = 0; i < 20; i++) {
            cte = "WITH c" + i + " AS (" + cte + ") SELECT * FROM c" + i;
        }
        cases.put("deeply_nested_cte_20", cte);

        // Wide SELECT 200 cols
        StringBuilder cols = new StringBuilder();
        for (int i = 0; i < 200; i++) {
            if (i > 0) cols.append(", ");
            cols.append("col_").append(i).append(" AS c").append(i);
        }
        cases.put("wide_select_200cols", "SELECT " + cols + " FROM t");

        // Many joined tables 30
        StringBuilder joins = new StringBuilder("t1");
        for (int i = 2; i <= 30; i++) {
            joins.append(" JOIN t").append(i).append(" ON t").append(i-1).append(".id = t").append(i).append(".id");
        }
        cases.put("many_joined_tables_30", "SELECT t1.id FROM " + joins);

        // Long identifier 1k
        cases.put("long_identifier_1k", "SELECT " + "a".repeat(1000) + " FROM t");

        // Edge cases
        cases.put("empty_input", "");
        cases.put("whitespace_only", "   \n\t  \n");
        cases.put("single_semicolon", ";");
        cases.put("single_token", "SELECT");
        cases.put("unterminated_string", "SELECT 'abc");
        cases.put("unterminated_comment", "SELECT /* abc");
        cases.put("valid_trivial", "SELECT 1");
        cases.put("valid_minimal", "SELECT a FROM b");

        // 50-level subquery
        String inner = "SELECT 1";
        for (int i = 0; i < 50; i++) {
            inner = "SELECT * FROM (" + inner + ") sub_" + i;
        }
        cases.put("deeper_nesting", inner);

        return cases;
    }

    public static void main(String[] args) throws Exception {
        Map<String, String> cases = buildCases();
        StringBuilder sb = new StringBuilder();
        sb.append("{\n  \"parser\": \"JSqlParser 5.3 (Java, multi-dialect)\",\n  \"results\": {\n");
        boolean first = true;

        for (Map.Entry<String, String> e : cases.entrySet()) {
            String name = e.getKey();
            String sql = e.getValue();
            int sqlLen = sql.length();
            int iters = sqlLen > 50_000 ? 5 : sqlLen > 10_000 ? 20 : sqlLen > 1000 ? 100 : 500;

            // Warmup
            for (int i = 0; i < 50; i++) {
                try { CCJSqlParserUtil.parse(sql); } catch (Exception ex) {}
            }

            List<Double> lats = new ArrayList<>(iters);
            boolean ok = true;
            String errMsg = null;
            for (int i = 0; i < iters; i++) {
                long t0 = System.nanoTime();
                try {
                    Statement s = CCJSqlParserUtil.parse(sql);
                    if (s == null) { ok = false; errMsg = "NullStatement"; }
                } catch (Throwable ex) {
                    ok = false;
                    errMsg = ex.getClass().getSimpleName();
                }
                lats.add((System.nanoTime() - t0) / 1000.0);
            }
            Collections.sort(lats);
            double med = lats.get(iters / 2);
            double p95 = percentile(lats, 95.0);
            double mx = lats.get(iters - 1);
            double totalSec = 0;
            for (double v : lats) totalSec += v;
            totalSec /= 1_000_000.0;
            double qps = iters / totalSec;

            System.err.printf("  %-32s (len=%6d, iters=%4d): median=%8.2fus, p95=%8.2fus, max=%8.2fus %s%n",
                name, sqlLen, iters, med, p95, mx, ok ? "OK" : "ERR:" + errMsg);

            if (!first) sb.append(",\n");
            first = false;
            sb.append("    \"").append(name).append("\": {\n");
            sb.append("      \"sql_len\": ").append(sqlLen).append(",\n");
            sb.append("      \"iters\": ").append(iters).append(",\n");
            sb.append("      \"ok\": ").append(ok).append(",\n");
            sb.append("      \"err\": ").append(errMsg == null ? "null" : "\"" + esc(errMsg) + "\"").append(",\n");
            sb.append(String.format(java.util.Locale.ROOT, "      \"median_us\": %.2f,%n", med));
            sb.append(String.format(java.util.Locale.ROOT, "      \"p95_us\": %.2f,%n", p95));
            sb.append(String.format(java.util.Locale.ROOT, "      \"max_us\": %.2f,%n", mx));
            sb.append(String.format(java.util.Locale.ROOT, "      \"throughput_qps\": %.2f%n", qps));
            sb.append("    }");
        }
        sb.append("\n  }\n}\n");
        Files.writeString(Paths.get(args[0]), sb.toString());
        System.err.println("Wrote " + args[0]);
    }

    static String esc(String s) { return s.replace("\\", "\\\\").replace("\"", "\\\""); }
}
