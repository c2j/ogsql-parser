"""Targeted large-statement benchmark for pglast, matching the Rust benches."""
import json
import time

import pglast

QUERIES = [
    ("simple_select", "SELECT id, name FROM users WHERE status = 'active'"),
    ("join_3way", "SELECT u.id, u.name, COUNT(o.id) FROM users u JOIN orders o ON u.id = o.user_id JOIN products p ON o.product_id = p.id WHERE u.created_at > '2024-01-01' GROUP BY u.id, u.name HAVING COUNT(o.id) > 5"),
    ("cte_chain", "WITH regional_sales AS (SELECT region, SUM(amount) AS total_sales FROM orders WHERE order_date >= '2024-01-01' GROUP BY region), top_regions AS (SELECT region FROM regional_sales WHERE total_sales > 1000000) SELECT r.region, r.total_sales, (SELECT COUNT(*) FROM customers c WHERE c.region = r.region) AS customer_count FROM regional_sales r WHERE r.region IN (SELECT region FROM top_regions) ORDER BY r.total_sales DESC LIMIT 10"),
    ("window_fn", "SELECT id, name, department, salary, RANK() OVER (PARTITION BY department ORDER BY salary DESC) AS dept_rank, SUM(salary) OVER (PARTITION BY department) AS dept_total FROM employees"),
    ("ddl_create_table", "CREATE TABLE orders (id BIGINT NOT NULL, user_id BIGINT NOT NULL, product_id BIGINT NOT NULL, amount DECIMAL(10,2) NOT NULL, status VARCHAR(20) NOT NULL DEFAULT 'pending', created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id), FOREIGN KEY (user_id) REFERENCES users(id), INDEX idx_status (status), INDEX idx_created (created_at))"),
    ("bulk_insert_10", "INSERT INTO t (id, name, value) VALUES (1, 'a', 100), (2, 'b', 200), (3, 'c', 300), (4, 'd', 400), (5, 'e', 500), (6, 'f', 600), (7, 'g', 700), (8, 'h', 800), (9, 'i', 900), (10, 'j', 1000)"),
    ("plpgsql_function", "CREATE OR REPLACE FUNCTION update_user_stats(p_user_id BIGINT) RETURNS VOID AS $$ BEGIN UPDATE users SET last_active = NOW() WHERE id = p_user_id; INSERT INTO user_stats (user_id, login_count, last_login) VALUES (p_user_id, 1, NOW()) ON CONFLICT (user_id) DO UPDATE SET login_count = user_stats.login_count + 1, last_login = NOW(); END; $$ LANGUAGE plpgsql"),
]

ITERS = 10_000


def percentile(sorted_vals, p):
    idx = int((p / 100.0) * (len(sorted_vals) - 1))
    return sorted_vals[min(idx, len(sorted_vals) - 1)]


def main():
    print(f"[pglast-large] running {len(QUERIES)} queries x {ITERS} iters", flush=True)
    results = []
    for name, sql in QUERIES:
        # warmup
        for _ in range(100):
            try:
                pglast.parse_sql(sql)
            except Exception:
                pass
        lats = []
        ok = True
        err_msg = None
        for _ in range(ITERS):
            t0 = time.perf_counter_ns()
            try:
                pglast.parse_sql(sql)
            except Exception as e:
                ok = False
                err_msg = f"{type(e).__name__}: {str(e)[:60]}"
            lats.append((time.perf_counter_ns() - t0) / 1000.0)  # us
        lats.sort()
        med = lats[ITERS // 2]
        p95 = percentile(lats, 95.0)
        total_sec = sum(lats) / 1_000_000.0
        qps = ITERS / total_sec
        results.append({
            "name": name,
            "sql": sql,
            "sql_len": len(sql),
            "iters": ITERS,
            "median_us": med,
            "p95_us": p95,
            "throughput_qps": qps,
            "ok": ok,
            "err": err_msg,
        })
        print(f"  {name}: median={med:.2f}us, p95={p95:.2f}us, qps={qps:.0f} {'OK' if ok else 'ERR'}", flush=True)

    output = {
        "parser": "pglast 7.14 (Python binding to libpg_query)",
        "per_query": results,
    }
    with open("/workspace/bench/results/pglast_large.json", "w") as f:
        json.dump(output, f, indent=2)
    print("[done] wrote /workspace/bench/results/pglast_large.json", flush=True)


if __name__ == "__main__":
    main()
